
# Face Generation
In this project, you'll use generative adversarial networks to generate new images of faces.
### Get the Data
You'll be using two datasets in this project:
- MNIST
- CelebA

Since the celebA dataset is complex and you're doing GANs in a project for the first time, we want you to test your neural network on MNIST before CelebA.  Running the GANs on MNIST will allow you to see how well your model trains sooner.

If you're using [FloydHub](https://www.floydhub.com/), set `data_dir` to "/input" and use the [FloydHub data ID](http://docs.floydhub.com/home/using_datasets/) "R5KrjnANiKVhLWAkpXhNBe".


```python
data_dir = './data'

# FloydHub - Use with data ID "R5KrjnANiKVhLWAkpXhNBe"
#data_dir = '/input'


"""
DON'T MODIFY ANYTHING IN THIS CELL
"""
import helper

helper.download_extract('mnist', data_dir)
helper.download_extract('celeba', data_dir)
```

    Found mnist Data
    Found celeba Data


## Explore the Data
### MNIST
As you're aware, the [MNIST](http://yann.lecun.com/exdb/mnist/) dataset contains images of handwritten digits. You can view the first number of examples by changing `show_n_images`. 


```python
show_n_images = 25

"""
DON'T MODIFY ANYTHING IN THIS CELL
"""
%matplotlib inline
import os
from glob import glob
from matplotlib import pyplot

mnist_images = helper.get_batch(glob(os.path.join(data_dir, 'mnist/*.jpg'))[:show_n_images], 28, 28, 'L')
pyplot.imshow(helper.images_square_grid(mnist_images, 'L'), cmap='gray')
```




    <matplotlib.image.AxesImage at 0x7f6c360db748>




![png](output_3_1.png)


### CelebA
The [CelebFaces Attributes Dataset (CelebA)](http://mmlab.ie.cuhk.edu.hk/projects/CelebA.html) dataset contains over 200,000 celebrity images with annotations.  Since you're going to be generating faces, you won't need the annotations.  You can view the first number of examples by changing `show_n_images`.


```python
show_n_images = 25

"""
DON'T MODIFY ANYTHING IN THIS CELL
"""
mnist_images = helper.get_batch(glob(os.path.join(data_dir, 'img_align_celeba/*.jpg'))[:show_n_images], 28, 28, 'RGB')
pyplot.imshow(helper.images_square_grid(mnist_images, 'RGB'))
```




    <matplotlib.image.AxesImage at 0x7f6c34f5d128>




![png](output_5_1.png)


## Preprocess the Data
Since the project's main focus is on building the GANs, we'll preprocess the data for you.  The values of the MNIST and CelebA dataset will be in the range of -0.5 to 0.5 of 28x28 dimensional images.  The CelebA images will be cropped to remove parts of the image that don't include a face, then resized down to 28x28.

The MNIST images are black and white images with a single [color channel](https://en.wikipedia.org/wiki/Channel_(digital_image%29) while the CelebA images have [3 color channels (RGB color channel)](https://en.wikipedia.org/wiki/Channel_(digital_image%29#RGB_Images).
## Build the Neural Network
You'll build the components necessary to build a GANs by implementing the following functions below:
- `model_inputs`
- `discriminator`
- `generator`
- `model_loss`
- `model_opt`
- `train`

### Check the Version of TensorFlow and Access to GPU
This will check to make sure you have the correct version of TensorFlow and access to a GPU


```python
"""
DON'T MODIFY ANYTHING IN THIS CELL
"""
from distutils.version import LooseVersion
import warnings
import tensorflow as tf

# Check TensorFlow Version
assert LooseVersion(tf.__version__) >= LooseVersion('1.0'), 'Please use TensorFlow version 1.0 or newer.  You are using {}'.format(tf.__version__)
print('TensorFlow Version: {}'.format(tf.__version__))

# Check for a GPU
if not tf.test.gpu_device_name():
    warnings.warn('No GPU found. Please use a GPU to train your neural network.')
else:
    print('Default GPU Device: {}'.format(tf.test.gpu_device_name()))
```

    TensorFlow Version: 1.1.0
    Default GPU Device: /gpu:0


### Input
Implement the `model_inputs` function to create TF Placeholders for the Neural Network. It should create the following placeholders:
- Real input images placeholder with rank 4 using `image_width`, `image_height`, and `image_channels`.
- Z input placeholder with rank 2 using `z_dim`.
- Learning rate placeholder with rank 0.

Return the placeholders in the following the tuple (tensor of real input images, tensor of z data)


```python
import problem_unittests as tests

def model_inputs(image_width, image_height, image_channels, z_dim):
    """
    Create the model inputs
    :param image_width: The input image width
    :param image_height: The input image height
    :param image_channels: The number of image channels
    :param z_dim: The dimension of Z
    :return: Tuple of (tensor of real input images, tensor of z data, learning rate)
    """
    # TODO: Implement Function
    real_input = tf.placeholder(tf.float32, (None,image_width,image_height, image_channels),name='real_input') 
    z_input = tf.placeholder(tf.float32,(None,z_dim),name='z_input')
    learning_rate = tf.placeholder(tf.float32)
    return real_input, z_input, learning_rate


"""
DON'T MODIFY ANYTHING IN THIS CELL THAT IS BELOW THIS LINE
"""
tests.test_model_inputs(model_inputs)
```

    Tests Passed


### Discriminator
Implement `discriminator` to create a discriminator neural network that discriminates on `images`.  This function should be able to reuse the variables in the neural network.  Use [`tf.variable_scope`](https://www.tensorflow.org/api_docs/python/tf/variable_scope) with a scope name of "discriminator" to allow the variables to be reused.  The function should return a tuple of (tensor output of the discriminator, tensor logits of the discriminator).


```python
def discriminator(images, reuse=False):
    """
    Create the discriminator network
    :param images: Tensor of input image(s)
    :param reuse: Boolean if the weights should be reused
    :return: Tuple of (tensor output of the discriminator, tensor logits of the discriminator)
    """
    alpha = 0.2
    # TODO: Implement Function
    with tf.variable_scope('discriminator', reuse=reuse):
        # Input layer is 28x28x3
        x1 = tf.layers.conv2d(images, 64, 5, strides=2, padding='same')
        relu1 = tf.maximum(alpha * x1, x1)
        # 14x14x64
        
        x2 = tf.layers.conv2d(relu1, 128, 5, strides=2, padding='same')
        bn2 = tf.layers.batch_normalization(x2, training=True)
        relu2 = tf.maximum(alpha * bn2, bn2)
        # 7x7x128
        
        x3 = tf.layers.conv2d(relu2, 256, 5, strides=2, padding='same')
        bn3 = tf.layers.batch_normalization(x3, training=True)
        relu3 = tf.maximum(alpha * bn3, bn3)
        # 4x4x256

        # Flatten it
        flat = tf.reshape(relu3, (-1, 4*4*256))
        logits = tf.layers.dense(flat, 1)
        out = tf.sigmoid(logits)
    return out, logits


"""
DON'T MODIFY ANYTHING IN THIS CELL THAT IS BELOW THIS LINE
"""
tests.test_discriminator(discriminator, tf)
```

    Tests Passed


### Generator
Implement `generator` to generate an image using `z`. This function should be able to reuse the variables in the neural network.  Use [`tf.variable_scope`](https://www.tensorflow.org/api_docs/python/tf/variable_scope) with a scope name of "generator" to allow the variables to be reused. The function should return the generated 28 x 28 x `out_channel_dim` images.


```python
def generator(z, out_channel_dim, is_train=True):
    """
    Create the generator network
    :param z: Input z
    :param out_channel_dim: The number of channels in the output image
    :param is_train: Boolean if generator is being used for training
    :return: The tensor output of the generator
    """

    # TODO: Implement Function
    with tf.variable_scope('generator',reuse=not is_train):
        alpha = 0.2
        # First fully connected layer
        x1 = tf.layers.dense(z, 2*2*512)
        # Reshape it to start the convolutional stack
        x1 = tf.reshape(x1, (-1, 2, 2, 512))
        x1 = tf.layers.batch_normalization(x1, training=is_train)
        x1 = tf.maximum(alpha * x1, x1)
        # 7x7x256 now
        
        x2 = tf.layers.conv2d_transpose(x1, 256, 5, strides=2, padding='valid')
        x2 = tf.layers.batch_normalization(x2, training=is_train)
        x2 = tf.maximum(alpha * x2, x2)
        # 14x14x128 now
        
        x3 = tf.layers.conv2d_transpose(x2, 128, 5, strides=2, padding='same')
        x3 = tf.layers.batch_normalization(x3, training=is_train)
        x3 = tf.maximum(alpha * x3, x3)
        # 28x28x64 now
        
        # Output layer
        logits = tf.layers.conv2d_transpose(x3, out_channel_dim, 5, strides=2, padding='same')
        # 32x32x3 now
        
        out = tf.tanh(logits)
    return out


"""
DON'T MODIFY ANYTHING IN THIS CELL THAT IS BELOW THIS LINE
"""
tests.test_generator(generator, tf)
```

    Tests Passed


### Loss
Implement `model_loss` to build the GANs for training and calculate the loss.  The function should return a tuple of (discriminator loss, generator loss).  Use the following functions you implemented:
- `discriminator(images, reuse=False)`
- `generator(z, out_channel_dim, is_train=True)`


```python
def model_loss(input_real, input_z, out_channel_dim):
    """
    Get the loss for the discriminator and generator
    :param input_real: Images from the real dataset
    :param input_z: Z input
    :param out_channel_dim: The number of channels in the output image
    :return: A tuple of (discriminator loss, generator loss)
    """
    # TODO: Implement Function
    g_model = generator(input_z, out_channel_dim)
    d_model_real, d_real_logits = discriminator(input_real)
    d_model_fake, d_fake_logits = discriminator(g_model,reuse=True)
    
    d_loss_real = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=d_real_logits,labels=tf.ones_like(d_model_real)))
    d_loss_fake = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=d_fake_logits,labels=tf.zeros_like(d_model_fake)))
    g_loss = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=d_fake_logits,labels=tf.ones_like(d_model_fake
                                                                                                            )))
    d_loss = d_loss_real + d_loss_fake
    return d_loss, g_loss


"""
DON'T MODIFY ANYTHING IN THIS CELL THAT IS BELOW THIS LINE
"""
tests.test_model_loss(model_loss)
```

    Tests Passed


### Optimization
Implement `model_opt` to create the optimization operations for the GANs. Use [`tf.trainable_variables`](https://www.tensorflow.org/api_docs/python/tf/trainable_variables) to get all the trainable variables.  Filter the variables with names that are in the discriminator and generator scope names.  The function should return a tuple of (discriminator training operation, generator training operation).


```python
def model_opt(d_loss, g_loss, learning_rate, beta1):
    """
    Get optimization operations
    :param d_loss: Discriminator loss Tensor
    :param g_loss: Generator loss Tensor
    :param learning_rate: Learning Rate Placeholder
    :param beta1: The exponential decay rate for the 1st moment in the optimizer
    :return: A tuple of (discriminator training operation, generator training operation)
    """
    # TODO: Implement Function
    tf_vars = tf.trainable_variables()
    g_vars = [var for var in tf_vars if var.name.startswith('generator')]
    d_vars = [var for var in tf_vars if var.name.startswith('discriminator')]
    
    
    d_train_opt = tf.train.AdamOptimizer(
        learning_rate, beta1=beta1).minimize(d_loss, var_list=d_vars)
    
    ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
    g_updates = [opt for opt in ops if opt.name.startswith('generator')]
    with tf.control_dependencies(g_updates):
        g_train_opt = tf.train.AdamOptimizer(
            learning_rate, beta1).minimize(g_loss, var_list=g_vars)
    return d_train_opt, g_train_opt


"""
DON'T MODIFY ANYTHING IN THIS CELL THAT IS BELOW THIS LINE
"""
tests.test_model_opt(model_opt, tf)
```

    Tests Passed


## Neural Network Training
### Show Output
Use this function to show the current output of the generator during training. It will help you determine how well the GANs is training.


```python
"""
DON'T MODIFY ANYTHING IN THIS CELL
"""
import numpy as np

def show_generator_output(sess, n_images, input_z, out_channel_dim, image_mode):
    """
    Show example output for the generator
    :param sess: TensorFlow session
    :param n_images: Number of Images to display
    :param input_z: Input Z Tensor
    :param out_channel_dim: The number of channels in the output image
    :param image_mode: The mode to use for images ("RGB" or "L")
    """
    cmap = None if image_mode == 'RGB' else 'gray'
    z_dim = input_z.get_shape().as_list()[-1]
    example_z = np.random.uniform(-1, 1, size=[n_images, z_dim])

    samples = sess.run(
        generator(input_z, out_channel_dim, False),
        feed_dict={input_z: example_z})

    images_grid = helper.images_square_grid(samples, image_mode)
    pyplot.imshow(images_grid, cmap=cmap)
    pyplot.show()
```

### Train
Implement `train` to build and train the GANs.  Use the following functions you implemented:
- `model_inputs(image_width, image_height, image_channels, z_dim)`
- `model_loss(input_real, input_z, out_channel_dim)`
- `model_opt(d_loss, g_loss, learning_rate, beta1)`

Use the `show_generator_output` to show `generator` output while you train. Running `show_generator_output` for every batch will drastically increase training time and increase the size of the notebook.  It's recommended to print the `generator` output every 100 batches.


```python
def train(epoch_count, batch_size, z_dim, learning_rate, beta1, get_batches, data_shape, data_image_mode):
    """
    Train the GAN
    :param epoch_count: Number of epochs
    :param batch_size: Batch Size
    :param z_dim: Z dimension
    :param learning_rate: Learning Rate
    :param beta1: The exponential decay rate for the 1st moment in the optimizer
    :param get_batches: Function to get batches
    :param data_shape: Shape of the data
    :param data_image_mode: The image mode to use for images ("RGB" or "L")
    """
    # TODO: Build Model
    _, img_width, img_height, img_channels = data_shape
    
    real_input, z_input, lr = model_inputs(
        img_width, img_height, img_channels, z_dim)
    
    d_loss, g_loss = model_loss(real_input, z_input, img_channels)
    d_opt, g_opt = model_opt(d_loss, g_loss, learning_rate, beta1)
    
    steps = 0
    print_every = 10
    show_every = 100
    losses = []
    n_images = 25
    
    with tf.Session() as sess:
        sess.run(tf.global_variables_initializer())
        for epoch_i in range(epoch_count):
            for batch_images in get_batches(batch_size):
                # TODO: Train Model
                steps += 1
                batch_images *= 2.0
                z_sample = np.random.uniform(-1, 1, (batch_size, z_dim))
                
                _ = sess.run(d_opt, feed_dict={
                        real_input: batch_images, z_input: z_sample, lr: learning_rate})
                _ = sess.run(g_opt, feed_dict={
                        z_input: z_sample, lr: learning_rate})
                
                if steps % print_every == 0:
                    train_loss_d = d_loss.eval({z_input: z_sample, real_input: batch_images})
                    train_loss_g = g_loss.eval({z_input: z_sample})
                    
                    print("Epoch {}/{}...".format(epoch_i+1, epoch_count),
                          "Discriminator Loss: {:.4f}...".format(train_loss_d),
                          "Generator Loss: {:.4f}".format(train_loss_g))
                    losses.append((train_loss_d, train_loss_g))
                
                if steps % show_every == 0:
                    show_generator_output(sess, n_images, z_input, img_channels, data_image_mode)
```

### MNIST
Test your GANs architecture on MNIST.  After 2 epochs, the GANs should be able to generate images that look like handwritten digits.  Make sure the loss of the generator is lower than the loss of the discriminator or close to 0.


```python
# batch_size = 128
# z_dim = 100
# learning_rate = 0.001
# beta1 = 0.5
batch_size = 128
z_dim = 150
learning_rate = 0.001
beta1 = 0.5

"""
DON'T MODIFY ANYTHING IN THIS CELL THAT IS BELOW THIS LINE
"""
epochs = 10

mnist_dataset = helper.Dataset('mnist', glob(os.path.join(data_dir, 'mnist/*.jpg')))

print(mnist_dataset.shape[1])
with tf.Graph().as_default():
    train(epochs, batch_size, z_dim, learning_rate, beta1, mnist_dataset.get_batches,
          mnist_dataset.shape, mnist_dataset.image_mode)
```

    28
    Epoch 1/10... Discriminator Loss: 0.4143... Generator Loss: 15.5914
    Epoch 1/10... Discriminator Loss: 4.0972... Generator Loss: 0.2995
    Epoch 1/10... Discriminator Loss: 0.1448... Generator Loss: 2.8092
    Epoch 1/10... Discriminator Loss: 0.1890... Generator Loss: 8.9097
    Epoch 1/10... Discriminator Loss: 0.0777... Generator Loss: 14.6486
    Epoch 1/10... Discriminator Loss: 0.0478... Generator Loss: 7.2039
    Epoch 1/10... Discriminator Loss: 0.1329... Generator Loss: 6.6240
    Epoch 1/10... Discriminator Loss: 1.3455... Generator Loss: 4.2101
    Epoch 1/10... Discriminator Loss: 0.1737... Generator Loss: 4.3102
    Epoch 1/10... Discriminator Loss: 0.1874... Generator Loss: 4.3169



![png](output_23_1.png)


    Epoch 1/10... Discriminator Loss: 0.3377... Generator Loss: 2.9918
    Epoch 1/10... Discriminator Loss: 0.5711... Generator Loss: 1.5467
    Epoch 1/10... Discriminator Loss: 0.2779... Generator Loss: 1.9198
    Epoch 1/10... Discriminator Loss: 0.1219... Generator Loss: 6.9521
    Epoch 1/10... Discriminator Loss: 0.7082... Generator Loss: 1.0077
    Epoch 1/10... Discriminator Loss: 0.2364... Generator Loss: 2.2460
    Epoch 1/10... Discriminator Loss: 0.7875... Generator Loss: 5.0614
    Epoch 1/10... Discriminator Loss: 0.3448... Generator Loss: 2.7856
    Epoch 1/10... Discriminator Loss: 0.2563... Generator Loss: 2.3091
    Epoch 1/10... Discriminator Loss: 0.1982... Generator Loss: 4.1654



![png](output_23_3.png)


    Epoch 1/10... Discriminator Loss: 0.1358... Generator Loss: 3.1205
    Epoch 1/10... Discriminator Loss: 0.2671... Generator Loss: 2.9637
    Epoch 1/10... Discriminator Loss: 0.5456... Generator Loss: 7.1798
    Epoch 1/10... Discriminator Loss: 0.0758... Generator Loss: 3.2781
    Epoch 1/10... Discriminator Loss: 0.1910... Generator Loss: 3.1343
    Epoch 1/10... Discriminator Loss: 3.1927... Generator Loss: 0.1552
    Epoch 1/10... Discriminator Loss: 0.3789... Generator Loss: 4.3358
    Epoch 1/10... Discriminator Loss: 0.3220... Generator Loss: 2.3783
    Epoch 1/10... Discriminator Loss: 0.0927... Generator Loss: 6.2727
    Epoch 1/10... Discriminator Loss: 0.5552... Generator Loss: 1.7190



![png](output_23_5.png)


    Epoch 1/10... Discriminator Loss: 0.2426... Generator Loss: 4.4037
    Epoch 1/10... Discriminator Loss: 0.3432... Generator Loss: 5.8493
    Epoch 1/10... Discriminator Loss: 0.2781... Generator Loss: 2.5141
    Epoch 1/10... Discriminator Loss: 1.8061... Generator Loss: 0.4140
    Epoch 1/10... Discriminator Loss: 0.7410... Generator Loss: 1.4265
    Epoch 1/10... Discriminator Loss: 0.6251... Generator Loss: 1.3942
    Epoch 1/10... Discriminator Loss: 0.3640... Generator Loss: 3.3596
    Epoch 1/10... Discriminator Loss: 0.3547... Generator Loss: 3.4816
    Epoch 1/10... Discriminator Loss: 0.4616... Generator Loss: 2.1251
    Epoch 1/10... Discriminator Loss: 0.4590... Generator Loss: 2.5424



![png](output_23_7.png)


    Epoch 1/10... Discriminator Loss: 0.6212... Generator Loss: 1.7288
    Epoch 1/10... Discriminator Loss: 0.8191... Generator Loss: 1.3353
    Epoch 1/10... Discriminator Loss: 0.5622... Generator Loss: 1.6158
    Epoch 1/10... Discriminator Loss: 0.7344... Generator Loss: 5.4169
    Epoch 1/10... Discriminator Loss: 1.4364... Generator Loss: 0.5183
    Epoch 1/10... Discriminator Loss: 0.7219... Generator Loss: 3.5254
    Epoch 2/10... Discriminator Loss: 0.5112... Generator Loss: 1.4079
    Epoch 2/10... Discriminator Loss: 0.8867... Generator Loss: 0.9674
    Epoch 2/10... Discriminator Loss: 0.8018... Generator Loss: 1.4848
    Epoch 2/10... Discriminator Loss: 1.2296... Generator Loss: 5.2303



![png](output_23_9.png)


    Epoch 2/10... Discriminator Loss: 0.7031... Generator Loss: 1.5521
    Epoch 2/10... Discriminator Loss: 0.7526... Generator Loss: 0.9670
    Epoch 2/10... Discriminator Loss: 0.8833... Generator Loss: 3.4754
    Epoch 2/10... Discriminator Loss: 0.5101... Generator Loss: 1.7441
    Epoch 2/10... Discriminator Loss: 0.6414... Generator Loss: 2.1460
    Epoch 2/10... Discriminator Loss: 0.5490... Generator Loss: 1.9928
    Epoch 2/10... Discriminator Loss: 0.6752... Generator Loss: 1.4018
    Epoch 2/10... Discriminator Loss: 0.7177... Generator Loss: 1.6840
    Epoch 2/10... Discriminator Loss: 0.7362... Generator Loss: 1.3218
    Epoch 2/10... Discriminator Loss: 0.6658... Generator Loss: 1.5365



![png](output_23_11.png)


    Epoch 2/10... Discriminator Loss: 0.9708... Generator Loss: 3.1545
    Epoch 2/10... Discriminator Loss: 0.8882... Generator Loss: 0.8796
    Epoch 2/10... Discriminator Loss: 0.9574... Generator Loss: 4.0439
    Epoch 2/10... Discriminator Loss: 0.7038... Generator Loss: 1.1581
    Epoch 2/10... Discriminator Loss: 0.7798... Generator Loss: 2.4638
    Epoch 2/10... Discriminator Loss: 0.6783... Generator Loss: 1.1459
    Epoch 2/10... Discriminator Loss: 0.5884... Generator Loss: 2.0716
    Epoch 2/10... Discriminator Loss: 0.6125... Generator Loss: 1.4393
    Epoch 2/10... Discriminator Loss: 0.5510... Generator Loss: 1.4119
    Epoch 2/10... Discriminator Loss: 1.1793... Generator Loss: 0.6122



![png](output_23_13.png)


    Epoch 2/10... Discriminator Loss: 1.2803... Generator Loss: 3.1310
    Epoch 2/10... Discriminator Loss: 0.7245... Generator Loss: 1.6074
    Epoch 2/10... Discriminator Loss: 0.7296... Generator Loss: 1.1857
    Epoch 2/10... Discriminator Loss: 0.5951... Generator Loss: 1.6972
    Epoch 2/10... Discriminator Loss: 0.8481... Generator Loss: 0.9467
    Epoch 2/10... Discriminator Loss: 0.5904... Generator Loss: 2.0403
    Epoch 2/10... Discriminator Loss: 1.3664... Generator Loss: 0.4807
    Epoch 2/10... Discriminator Loss: 0.9151... Generator Loss: 0.8566
    Epoch 2/10... Discriminator Loss: 0.8954... Generator Loss: 2.5672
    Epoch 2/10... Discriminator Loss: 1.0433... Generator Loss: 0.7065



![png](output_23_15.png)


    Epoch 2/10... Discriminator Loss: 0.7343... Generator Loss: 1.2041
    Epoch 2/10... Discriminator Loss: 2.2618... Generator Loss: 0.1852
    Epoch 2/10... Discriminator Loss: 0.9829... Generator Loss: 0.7366
    Epoch 2/10... Discriminator Loss: 0.7980... Generator Loss: 1.0619
    Epoch 2/10... Discriminator Loss: 0.6130... Generator Loss: 1.4022
    Epoch 2/10... Discriminator Loss: 1.1321... Generator Loss: 0.6314
    Epoch 2/10... Discriminator Loss: 1.1706... Generator Loss: 0.6259
    Epoch 2/10... Discriminator Loss: 1.0584... Generator Loss: 3.0748
    Epoch 2/10... Discriminator Loss: 0.8177... Generator Loss: 1.0372
    Epoch 2/10... Discriminator Loss: 1.3338... Generator Loss: 0.4548



![png](output_23_17.png)


    Epoch 2/10... Discriminator Loss: 1.2012... Generator Loss: 2.8743
    Epoch 2/10... Discriminator Loss: 1.0422... Generator Loss: 0.6264
    Epoch 2/10... Discriminator Loss: 0.8794... Generator Loss: 0.7984
    Epoch 3/10... Discriminator Loss: 0.9674... Generator Loss: 0.7190
    Epoch 3/10... Discriminator Loss: 0.9366... Generator Loss: 0.8727
    Epoch 3/10... Discriminator Loss: 0.6166... Generator Loss: 2.1569
    Epoch 3/10... Discriminator Loss: 1.3150... Generator Loss: 1.8523
    Epoch 3/10... Discriminator Loss: 1.1291... Generator Loss: 0.7335
    Epoch 3/10... Discriminator Loss: 0.9133... Generator Loss: 0.8397
    Epoch 3/10... Discriminator Loss: 0.8399... Generator Loss: 2.0734



![png](output_23_19.png)


    Epoch 3/10... Discriminator Loss: 0.6598... Generator Loss: 1.1725
    Epoch 3/10... Discriminator Loss: 7.6044... Generator Loss: 8.1419
    Epoch 3/10... Discriminator Loss: 0.8787... Generator Loss: 1.6690
    Epoch 3/10... Discriminator Loss: 0.8817... Generator Loss: 0.8641
    Epoch 3/10... Discriminator Loss: 0.9238... Generator Loss: 0.6845
    Epoch 3/10... Discriminator Loss: 0.5522... Generator Loss: 1.6496
    Epoch 3/10... Discriminator Loss: 1.1506... Generator Loss: 1.1431
    Epoch 3/10... Discriminator Loss: 1.2142... Generator Loss: 0.5858
    Epoch 3/10... Discriminator Loss: 1.2959... Generator Loss: 2.0337
    Epoch 3/10... Discriminator Loss: 1.4663... Generator Loss: 0.3707



![png](output_23_21.png)


    Epoch 3/10... Discriminator Loss: 0.7247... Generator Loss: 1.0091
    Epoch 3/10... Discriminator Loss: 0.8488... Generator Loss: 1.3182
    Epoch 3/10... Discriminator Loss: 0.7325... Generator Loss: 1.2454
    Epoch 3/10... Discriminator Loss: 0.5843... Generator Loss: 2.0947
    Epoch 3/10... Discriminator Loss: 0.8320... Generator Loss: 1.2230
    Epoch 3/10... Discriminator Loss: 0.7624... Generator Loss: 1.1808
    Epoch 3/10... Discriminator Loss: 0.5981... Generator Loss: 1.7116
    Epoch 3/10... Discriminator Loss: 0.8205... Generator Loss: 0.8966
    Epoch 3/10... Discriminator Loss: 0.9055... Generator Loss: 0.8414
    Epoch 3/10... Discriminator Loss: 1.1286... Generator Loss: 1.7979



![png](output_23_23.png)


    Epoch 3/10... Discriminator Loss: 0.8251... Generator Loss: 1.0268
    Epoch 3/10... Discriminator Loss: 0.9684... Generator Loss: 0.8437
    Epoch 3/10... Discriminator Loss: 0.8289... Generator Loss: 1.1024
    Epoch 3/10... Discriminator Loss: 0.9567... Generator Loss: 0.8957
    Epoch 3/10... Discriminator Loss: 1.7788... Generator Loss: 0.2997
    Epoch 3/10... Discriminator Loss: 0.7826... Generator Loss: 1.0366
    Epoch 3/10... Discriminator Loss: 0.6587... Generator Loss: 1.0508
    Epoch 3/10... Discriminator Loss: 0.7407... Generator Loss: 2.0778
    Epoch 3/10... Discriminator Loss: 1.1730... Generator Loss: 0.5546
    Epoch 3/10... Discriminator Loss: 0.6512... Generator Loss: 1.7406



![png](output_23_25.png)


    Epoch 3/10... Discriminator Loss: 2.4456... Generator Loss: 3.4784
    Epoch 3/10... Discriminator Loss: 1.1547... Generator Loss: 1.8813
    Epoch 3/10... Discriminator Loss: 1.5884... Generator Loss: 0.3394
    Epoch 3/10... Discriminator Loss: 0.8733... Generator Loss: 2.7908
    Epoch 3/10... Discriminator Loss: 1.0853... Generator Loss: 0.7342
    Epoch 3/10... Discriminator Loss: 1.0084... Generator Loss: 0.7331
    Epoch 3/10... Discriminator Loss: 1.0960... Generator Loss: 0.6537
    Epoch 3/10... Discriminator Loss: 0.9444... Generator Loss: 0.8228
    Epoch 3/10... Discriminator Loss: 0.8305... Generator Loss: 2.1581
    Epoch 3/10... Discriminator Loss: 0.9834... Generator Loss: 0.6812



![png](output_23_27.png)


    Epoch 4/10... Discriminator Loss: 0.8002... Generator Loss: 1.0930
    Epoch 4/10... Discriminator Loss: 0.7557... Generator Loss: 1.0894
    Epoch 4/10... Discriminator Loss: 0.7162... Generator Loss: 1.5843
    Epoch 4/10... Discriminator Loss: 1.6493... Generator Loss: 0.3470
    Epoch 4/10... Discriminator Loss: 0.7412... Generator Loss: 1.5009
    Epoch 4/10... Discriminator Loss: 0.7852... Generator Loss: 1.0639
    Epoch 4/10... Discriminator Loss: 0.7113... Generator Loss: 2.1425
    Epoch 4/10... Discriminator Loss: 1.4830... Generator Loss: 0.3805
    Epoch 4/10... Discriminator Loss: 0.7049... Generator Loss: 1.1154
    Epoch 4/10... Discriminator Loss: 0.8004... Generator Loss: 2.0172



![png](output_23_29.png)


    Epoch 4/10... Discriminator Loss: 1.1205... Generator Loss: 1.9584
    Epoch 4/10... Discriminator Loss: 0.9881... Generator Loss: 0.8168
    Epoch 4/10... Discriminator Loss: 0.8767... Generator Loss: 1.1247
    Epoch 4/10... Discriminator Loss: 1.0428... Generator Loss: 0.6442
    Epoch 4/10... Discriminator Loss: 0.8500... Generator Loss: 1.0901
    Epoch 4/10... Discriminator Loss: 0.6293... Generator Loss: 1.3928
    Epoch 4/10... Discriminator Loss: 1.9201... Generator Loss: 3.0417
    Epoch 4/10... Discriminator Loss: 0.9246... Generator Loss: 1.3626
    Epoch 4/10... Discriminator Loss: 1.1292... Generator Loss: 0.6203
    Epoch 4/10... Discriminator Loss: 0.8423... Generator Loss: 1.3949



![png](output_23_31.png)


    Epoch 4/10... Discriminator Loss: 0.8608... Generator Loss: 1.5794
    Epoch 4/10... Discriminator Loss: 0.9056... Generator Loss: 0.9045
    Epoch 4/10... Discriminator Loss: 1.3416... Generator Loss: 3.4525
    Epoch 4/10... Discriminator Loss: 1.3562... Generator Loss: 0.4680
    Epoch 4/10... Discriminator Loss: 0.9485... Generator Loss: 0.7138
    Epoch 4/10... Discriminator Loss: 1.0605... Generator Loss: 0.6453
    Epoch 4/10... Discriminator Loss: 0.8558... Generator Loss: 2.0277
    Epoch 4/10... Discriminator Loss: 0.7780... Generator Loss: 0.8893
    Epoch 4/10... Discriminator Loss: 0.8546... Generator Loss: 1.5037
    Epoch 4/10... Discriminator Loss: 1.3245... Generator Loss: 2.6029



![png](output_23_33.png)


    Epoch 4/10... Discriminator Loss: 0.8370... Generator Loss: 1.6809
    Epoch 4/10... Discriminator Loss: 1.1931... Generator Loss: 0.5141
    Epoch 4/10... Discriminator Loss: 2.5068... Generator Loss: 0.1234
    Epoch 4/10... Discriminator Loss: 1.0151... Generator Loss: 0.9248
    Epoch 4/10... Discriminator Loss: 0.9754... Generator Loss: 1.4065
    Epoch 4/10... Discriminator Loss: 1.1398... Generator Loss: 0.7096
    Epoch 4/10... Discriminator Loss: 1.0828... Generator Loss: 0.6856
    Epoch 4/10... Discriminator Loss: 1.2702... Generator Loss: 0.5100
    Epoch 4/10... Discriminator Loss: 1.0392... Generator Loss: 0.6492
    Epoch 4/10... Discriminator Loss: 0.7282... Generator Loss: 1.4595



![png](output_23_35.png)


    Epoch 4/10... Discriminator Loss: 1.2911... Generator Loss: 0.4482
    Epoch 4/10... Discriminator Loss: 0.8719... Generator Loss: 1.1644
    Epoch 4/10... Discriminator Loss: 0.8078... Generator Loss: 1.0770
    Epoch 4/10... Discriminator Loss: 0.6462... Generator Loss: 2.6730
    Epoch 4/10... Discriminator Loss: 0.8761... Generator Loss: 0.8446
    Epoch 4/10... Discriminator Loss: 1.0032... Generator Loss: 0.6646
    Epoch 4/10... Discriminator Loss: 1.3225... Generator Loss: 2.8531
    Epoch 5/10... Discriminator Loss: 0.8102... Generator Loss: 1.7841
    Epoch 5/10... Discriminator Loss: 0.6674... Generator Loss: 1.0257
    Epoch 5/10... Discriminator Loss: 0.7843... Generator Loss: 0.8880



![png](output_23_37.png)


    Epoch 5/10... Discriminator Loss: 0.4336... Generator Loss: 1.4460
    Epoch 5/10... Discriminator Loss: 0.5506... Generator Loss: 1.2444
    Epoch 5/10... Discriminator Loss: 4.1366... Generator Loss: 0.1640
    Epoch 5/10... Discriminator Loss: 1.0112... Generator Loss: 0.9881
    Epoch 5/10... Discriminator Loss: 1.2763... Generator Loss: 0.5506
    Epoch 5/10... Discriminator Loss: 0.7425... Generator Loss: 2.3716
    Epoch 5/10... Discriminator Loss: 1.9847... Generator Loss: 0.2669
    Epoch 5/10... Discriminator Loss: 0.7667... Generator Loss: 0.9382
    Epoch 5/10... Discriminator Loss: 1.9684... Generator Loss: 0.2866
    Epoch 5/10... Discriminator Loss: 1.4008... Generator Loss: 0.4231



![png](output_23_39.png)


    Epoch 5/10... Discriminator Loss: 1.1968... Generator Loss: 0.5399
    Epoch 5/10... Discriminator Loss: 0.6180... Generator Loss: 1.1628
    Epoch 5/10... Discriminator Loss: 0.6027... Generator Loss: 1.5280
    Epoch 5/10... Discriminator Loss: 0.7146... Generator Loss: 2.5595
    Epoch 5/10... Discriminator Loss: 0.7699... Generator Loss: 2.0552
    Epoch 5/10... Discriminator Loss: 0.9231... Generator Loss: 0.8145
    Epoch 5/10... Discriminator Loss: 0.5808... Generator Loss: 1.3153
    Epoch 5/10... Discriminator Loss: 0.5678... Generator Loss: 1.3332
    Epoch 5/10... Discriminator Loss: 0.4916... Generator Loss: 1.7254
    Epoch 5/10... Discriminator Loss: 2.1682... Generator Loss: 4.7011



![png](output_23_41.png)


    Epoch 5/10... Discriminator Loss: 0.7733... Generator Loss: 1.2206
    Epoch 5/10... Discriminator Loss: 0.8494... Generator Loss: 0.9134
    Epoch 5/10... Discriminator Loss: 0.9010... Generator Loss: 0.8549
    Epoch 5/10... Discriminator Loss: 0.8449... Generator Loss: 0.7939
    Epoch 5/10... Discriminator Loss: 1.4625... Generator Loss: 0.3737
    Epoch 5/10... Discriminator Loss: 0.7741... Generator Loss: 1.6039
    Epoch 5/10... Discriminator Loss: 0.5427... Generator Loss: 1.3729
    Epoch 5/10... Discriminator Loss: 0.5773... Generator Loss: 1.1648
    Epoch 5/10... Discriminator Loss: 0.5838... Generator Loss: 1.2145
    Epoch 5/10... Discriminator Loss: 0.4975... Generator Loss: 1.4288



![png](output_23_43.png)


    Epoch 5/10... Discriminator Loss: 0.7522... Generator Loss: 0.9199
    Epoch 5/10... Discriminator Loss: 0.9149... Generator Loss: 0.7309
    Epoch 5/10... Discriminator Loss: 1.1773... Generator Loss: 2.8881
    Epoch 5/10... Discriminator Loss: 0.7465... Generator Loss: 1.0820
    Epoch 5/10... Discriminator Loss: 1.5921... Generator Loss: 0.5584
    Epoch 5/10... Discriminator Loss: 1.1709... Generator Loss: 0.6510
    Epoch 5/10... Discriminator Loss: 0.7371... Generator Loss: 0.9961
    Epoch 5/10... Discriminator Loss: 0.7164... Generator Loss: 1.0438
    Epoch 5/10... Discriminator Loss: 0.8742... Generator Loss: 0.8270
    Epoch 5/10... Discriminator Loss: 0.5687... Generator Loss: 2.0692



![png](output_23_45.png)


    Epoch 5/10... Discriminator Loss: 0.6607... Generator Loss: 1.0173
    Epoch 5/10... Discriminator Loss: 1.0310... Generator Loss: 2.0252
    Epoch 5/10... Discriminator Loss: 0.6426... Generator Loss: 2.2036
    Epoch 5/10... Discriminator Loss: 1.3527... Generator Loss: 0.5560
    Epoch 6/10... Discriminator Loss: 0.6485... Generator Loss: 1.2758
    Epoch 6/10... Discriminator Loss: 0.6007... Generator Loss: 2.5009
    Epoch 6/10... Discriminator Loss: 0.7979... Generator Loss: 1.3403
    Epoch 6/10... Discriminator Loss: 0.6783... Generator Loss: 2.0424
    Epoch 6/10... Discriminator Loss: 2.1129... Generator Loss: 0.2757
    Epoch 6/10... Discriminator Loss: 0.6667... Generator Loss: 1.4925



![png](output_23_47.png)


    Epoch 6/10... Discriminator Loss: 0.8426... Generator Loss: 1.0328
    Epoch 6/10... Discriminator Loss: 0.8987... Generator Loss: 0.8318
    Epoch 6/10... Discriminator Loss: 1.4973... Generator Loss: 3.6768
    Epoch 6/10... Discriminator Loss: 0.9391... Generator Loss: 2.8620
    Epoch 6/10... Discriminator Loss: 0.8531... Generator Loss: 0.8904
    Epoch 6/10... Discriminator Loss: 0.8402... Generator Loss: 0.9798
    Epoch 6/10... Discriminator Loss: 0.4275... Generator Loss: 1.8800
    Epoch 6/10... Discriminator Loss: 1.3537... Generator Loss: 0.4447
    Epoch 6/10... Discriminator Loss: 1.0041... Generator Loss: 0.7282
    Epoch 6/10... Discriminator Loss: 0.9780... Generator Loss: 1.6687



![png](output_23_49.png)


    Epoch 6/10... Discriminator Loss: 0.7782... Generator Loss: 1.1782
    Epoch 6/10... Discriminator Loss: 0.9844... Generator Loss: 0.7394
    Epoch 6/10... Discriminator Loss: 0.6893... Generator Loss: 1.0693
    Epoch 6/10... Discriminator Loss: 0.8542... Generator Loss: 0.8204
    Epoch 6/10... Discriminator Loss: 0.5960... Generator Loss: 1.1841
    Epoch 6/10... Discriminator Loss: 0.8149... Generator Loss: 2.4926
    Epoch 6/10... Discriminator Loss: 0.9288... Generator Loss: 0.7721
    Epoch 6/10... Discriminator Loss: 0.7726... Generator Loss: 1.6227
    Epoch 6/10... Discriminator Loss: 0.5223... Generator Loss: 1.5306
    Epoch 6/10... Discriminator Loss: 1.3724... Generator Loss: 2.7347



![png](output_23_51.png)


    Epoch 6/10... Discriminator Loss: 1.2485... Generator Loss: 0.6227
    Epoch 6/10... Discriminator Loss: 0.7653... Generator Loss: 1.0011
    Epoch 6/10... Discriminator Loss: 0.6781... Generator Loss: 1.0318
    Epoch 6/10... Discriminator Loss: 0.5152... Generator Loss: 1.3170
    Epoch 6/10... Discriminator Loss: 0.7993... Generator Loss: 0.9644
    Epoch 6/10... Discriminator Loss: 0.9198... Generator Loss: 1.1589
    Epoch 6/10... Discriminator Loss: 1.4104... Generator Loss: 0.4660
    Epoch 6/10... Discriminator Loss: 1.3456... Generator Loss: 0.4516
    Epoch 6/10... Discriminator Loss: 0.7125... Generator Loss: 1.0364
    Epoch 6/10... Discriminator Loss: 0.8596... Generator Loss: 0.8954



![png](output_23_53.png)


    Epoch 6/10... Discriminator Loss: 1.2623... Generator Loss: 0.5192
    Epoch 6/10... Discriminator Loss: 0.8058... Generator Loss: 0.9268
    Epoch 6/10... Discriminator Loss: 0.4386... Generator Loss: 1.6360
    Epoch 6/10... Discriminator Loss: 0.6485... Generator Loss: 1.0729
    Epoch 6/10... Discriminator Loss: 0.3388... Generator Loss: 1.8821
    Epoch 6/10... Discriminator Loss: 0.2999... Generator Loss: 2.1783
    Epoch 6/10... Discriminator Loss: 0.7497... Generator Loss: 0.9442
    Epoch 6/10... Discriminator Loss: 1.8175... Generator Loss: 5.1190
    Epoch 6/10... Discriminator Loss: 1.6724... Generator Loss: 0.3452
    Epoch 6/10... Discriminator Loss: 1.1296... Generator Loss: 0.9722



![png](output_23_55.png)


    Epoch 7/10... Discriminator Loss: 0.6467... Generator Loss: 2.1660
    Epoch 7/10... Discriminator Loss: 1.4220... Generator Loss: 0.4638
    Epoch 7/10... Discriminator Loss: 0.4972... Generator Loss: 1.8008
    Epoch 7/10... Discriminator Loss: 0.6196... Generator Loss: 2.5938
    Epoch 7/10... Discriminator Loss: 1.3841... Generator Loss: 0.5716
    Epoch 7/10... Discriminator Loss: 1.2580... Generator Loss: 3.4330
    Epoch 7/10... Discriminator Loss: 1.0152... Generator Loss: 2.5507
    Epoch 7/10... Discriminator Loss: 0.4940... Generator Loss: 1.5183
    Epoch 7/10... Discriminator Loss: 1.1016... Generator Loss: 0.6596
    Epoch 7/10... Discriminator Loss: 0.4807... Generator Loss: 1.2872



![png](output_23_57.png)


    Epoch 7/10... Discriminator Loss: 0.5821... Generator Loss: 1.2645
    Epoch 7/10... Discriminator Loss: 0.8671... Generator Loss: 0.8536
    Epoch 7/10... Discriminator Loss: 0.6518... Generator Loss: 1.1300
    Epoch 7/10... Discriminator Loss: 0.3814... Generator Loss: 1.6927
    Epoch 7/10... Discriminator Loss: 0.5564... Generator Loss: 1.2978
    Epoch 7/10... Discriminator Loss: 1.3987... Generator Loss: 0.6513
    Epoch 7/10... Discriminator Loss: 1.4888... Generator Loss: 0.4175
    Epoch 7/10... Discriminator Loss: 0.6733... Generator Loss: 1.0782
    Epoch 7/10... Discriminator Loss: 0.5473... Generator Loss: 1.3602
    Epoch 7/10... Discriminator Loss: 0.5167... Generator Loss: 1.2675



![png](output_23_59.png)


    Epoch 7/10... Discriminator Loss: 1.4826... Generator Loss: 0.4462
    Epoch 7/10... Discriminator Loss: 0.7195... Generator Loss: 1.8737
    Epoch 7/10... Discriminator Loss: 0.4718... Generator Loss: 1.8880
    Epoch 7/10... Discriminator Loss: 0.3397... Generator Loss: 1.7756
    Epoch 7/10... Discriminator Loss: 0.7425... Generator Loss: 0.9619
    Epoch 7/10... Discriminator Loss: 1.4591... Generator Loss: 3.3359
    Epoch 7/10... Discriminator Loss: 0.9613... Generator Loss: 0.8099
    Epoch 7/10... Discriminator Loss: 0.6363... Generator Loss: 2.3053
    Epoch 7/10... Discriminator Loss: 0.7613... Generator Loss: 2.1573
    Epoch 7/10... Discriminator Loss: 1.8074... Generator Loss: 0.3411



![png](output_23_61.png)


    Epoch 7/10... Discriminator Loss: 0.7432... Generator Loss: 0.9843
    Epoch 7/10... Discriminator Loss: 1.2327... Generator Loss: 0.5844
    Epoch 7/10... Discriminator Loss: 0.5968... Generator Loss: 1.4438
    Epoch 7/10... Discriminator Loss: 0.3678... Generator Loss: 1.6512
    Epoch 7/10... Discriminator Loss: 1.3462... Generator Loss: 0.4742
    Epoch 7/10... Discriminator Loss: 0.5345... Generator Loss: 1.4754
    Epoch 7/10... Discriminator Loss: 0.6042... Generator Loss: 1.5342
    Epoch 7/10... Discriminator Loss: 0.6801... Generator Loss: 1.1256
    Epoch 7/10... Discriminator Loss: 0.8686... Generator Loss: 0.8911
    Epoch 7/10... Discriminator Loss: 0.4944... Generator Loss: 1.3490



![png](output_23_63.png)


    Epoch 7/10... Discriminator Loss: 1.8229... Generator Loss: 0.3193
    Epoch 7/10... Discriminator Loss: 0.6880... Generator Loss: 1.5454
    Epoch 7/10... Discriminator Loss: 0.8493... Generator Loss: 0.8625
    Epoch 7/10... Discriminator Loss: 0.7777... Generator Loss: 1.9914
    Epoch 7/10... Discriminator Loss: 0.5711... Generator Loss: 2.4052
    Epoch 7/10... Discriminator Loss: 0.7062... Generator Loss: 1.1945
    Epoch 7/10... Discriminator Loss: 0.9825... Generator Loss: 2.3397
    Epoch 8/10... Discriminator Loss: 1.1313... Generator Loss: 0.7023
    Epoch 8/10... Discriminator Loss: 0.7032... Generator Loss: 0.9719
    Epoch 8/10... Discriminator Loss: 0.6852... Generator Loss: 1.0043



![png](output_23_65.png)


    Epoch 8/10... Discriminator Loss: 0.5162... Generator Loss: 1.3511
    Epoch 8/10... Discriminator Loss: 0.5534... Generator Loss: 1.3391
    Epoch 8/10... Discriminator Loss: 0.4655... Generator Loss: 1.3805
    Epoch 8/10... Discriminator Loss: 0.7103... Generator Loss: 1.0327
    Epoch 8/10... Discriminator Loss: 0.4429... Generator Loss: 3.0182
    Epoch 8/10... Discriminator Loss: 0.7563... Generator Loss: 1.1906
    Epoch 8/10... Discriminator Loss: 0.9584... Generator Loss: 3.2130
    Epoch 8/10... Discriminator Loss: 0.5675... Generator Loss: 1.7905
    Epoch 8/10... Discriminator Loss: 0.6378... Generator Loss: 2.3349
    Epoch 8/10... Discriminator Loss: 0.6014... Generator Loss: 2.3512



![png](output_23_67.png)


    Epoch 8/10... Discriminator Loss: 1.1773... Generator Loss: 3.2221
    Epoch 8/10... Discriminator Loss: 0.4134... Generator Loss: 2.3833
    Epoch 8/10... Discriminator Loss: 0.5180... Generator Loss: 1.4164
    Epoch 8/10... Discriminator Loss: 0.5446... Generator Loss: 1.4529
    Epoch 8/10... Discriminator Loss: 0.6797... Generator Loss: 1.0190
    Epoch 8/10... Discriminator Loss: 0.7290... Generator Loss: 0.9576
    Epoch 8/10... Discriminator Loss: 0.7523... Generator Loss: 0.9409
    Epoch 8/10... Discriminator Loss: 0.4278... Generator Loss: 1.4448
    Epoch 8/10... Discriminator Loss: 0.6068... Generator Loss: 1.2210
    Epoch 8/10... Discriminator Loss: 0.5552... Generator Loss: 1.2402



![png](output_23_69.png)


    Epoch 8/10... Discriminator Loss: 0.2811... Generator Loss: 1.9203
    Epoch 8/10... Discriminator Loss: 1.3716... Generator Loss: 0.4705
    Epoch 8/10... Discriminator Loss: 0.5893... Generator Loss: 3.5949
    Epoch 8/10... Discriminator Loss: 0.9148... Generator Loss: 2.1337
    Epoch 8/10... Discriminator Loss: 0.5968... Generator Loss: 1.2251
    Epoch 8/10... Discriminator Loss: 0.8727... Generator Loss: 0.8469
    Epoch 8/10... Discriminator Loss: 0.5327... Generator Loss: 2.1526
    Epoch 8/10... Discriminator Loss: 0.5080... Generator Loss: 2.2013
    Epoch 8/10... Discriminator Loss: 0.4864... Generator Loss: 2.2816
    Epoch 8/10... Discriminator Loss: 1.0599... Generator Loss: 4.1484



![png](output_23_71.png)


    Epoch 8/10... Discriminator Loss: 0.6308... Generator Loss: 1.2221
    Epoch 8/10... Discriminator Loss: 0.5535... Generator Loss: 1.2501
    Epoch 8/10... Discriminator Loss: 0.7137... Generator Loss: 0.9975
    Epoch 8/10... Discriminator Loss: 0.9528... Generator Loss: 0.7329
    Epoch 8/10... Discriminator Loss: 0.5979... Generator Loss: 1.2086
    Epoch 8/10... Discriminator Loss: 0.4459... Generator Loss: 1.5117
    Epoch 8/10... Discriminator Loss: 0.6344... Generator Loss: 1.1009
    Epoch 8/10... Discriminator Loss: 0.3850... Generator Loss: 1.5572
    Epoch 8/10... Discriminator Loss: 0.5040... Generator Loss: 1.3390
    Epoch 8/10... Discriminator Loss: 0.2857... Generator Loss: 1.8685



![png](output_23_73.png)


    Epoch 8/10... Discriminator Loss: 0.4871... Generator Loss: 1.4493
    Epoch 8/10... Discriminator Loss: 1.0000... Generator Loss: 0.6639
    Epoch 8/10... Discriminator Loss: 0.3188... Generator Loss: 1.7928
    Epoch 8/10... Discriminator Loss: 0.3151... Generator Loss: 1.8577
    Epoch 9/10... Discriminator Loss: 0.3703... Generator Loss: 1.6597
    Epoch 9/10... Discriminator Loss: 0.2197... Generator Loss: 2.3475
    Epoch 9/10... Discriminator Loss: 0.9023... Generator Loss: 1.6486
    Epoch 9/10... Discriminator Loss: 1.7210... Generator Loss: 0.4184
    Epoch 9/10... Discriminator Loss: 0.4423... Generator Loss: 1.7682
    Epoch 9/10... Discriminator Loss: 0.8453... Generator Loss: 0.8831



![png](output_23_75.png)


    Epoch 9/10... Discriminator Loss: 0.6161... Generator Loss: 1.2088
    Epoch 9/10... Discriminator Loss: 2.8397... Generator Loss: 5.7940
    Epoch 9/10... Discriminator Loss: 0.8154... Generator Loss: 0.9567
    Epoch 9/10... Discriminator Loss: 1.1198... Generator Loss: 0.6641
    Epoch 9/10... Discriminator Loss: 0.9745... Generator Loss: 3.6572
    Epoch 9/10... Discriminator Loss: 1.5977... Generator Loss: 0.4035
    Epoch 9/10... Discriminator Loss: 0.7953... Generator Loss: 3.1043
    Epoch 9/10... Discriminator Loss: 1.4311... Generator Loss: 0.4298
    Epoch 9/10... Discriminator Loss: 0.8306... Generator Loss: 0.8625
    Epoch 9/10... Discriminator Loss: 0.3504... Generator Loss: 1.8379



![png](output_23_77.png)


    Epoch 9/10... Discriminator Loss: 0.5109... Generator Loss: 1.2865
    Epoch 9/10... Discriminator Loss: 0.4838... Generator Loss: 1.3848
    Epoch 9/10... Discriminator Loss: 0.6038... Generator Loss: 1.1342
    Epoch 9/10... Discriminator Loss: 0.2981... Generator Loss: 1.9603
    Epoch 9/10... Discriminator Loss: 2.6351... Generator Loss: 5.3448
    Epoch 9/10... Discriminator Loss: 0.8099... Generator Loss: 1.8516
    Epoch 9/10... Discriminator Loss: 0.5993... Generator Loss: 1.9731
    Epoch 9/10... Discriminator Loss: 1.0548... Generator Loss: 2.8967
    Epoch 9/10... Discriminator Loss: 0.8650... Generator Loss: 1.4334
    Epoch 9/10... Discriminator Loss: 0.6608... Generator Loss: 1.2833



![png](output_23_79.png)


    Epoch 9/10... Discriminator Loss: 0.7397... Generator Loss: 3.0000
    Epoch 9/10... Discriminator Loss: 0.6096... Generator Loss: 1.2212
    Epoch 9/10... Discriminator Loss: 0.7068... Generator Loss: 3.0055
    Epoch 9/10... Discriminator Loss: 0.6214... Generator Loss: 1.1359
    Epoch 9/10... Discriminator Loss: 0.4501... Generator Loss: 1.6160
    Epoch 9/10... Discriminator Loss: 0.4022... Generator Loss: 1.5431
    Epoch 9/10... Discriminator Loss: 0.8150... Generator Loss: 0.8645
    Epoch 9/10... Discriminator Loss: 3.0425... Generator Loss: 0.2655
    Epoch 9/10... Discriminator Loss: 0.7913... Generator Loss: 1.3723
    Epoch 9/10... Discriminator Loss: 0.6859... Generator Loss: 1.9770



![png](output_23_81.png)


    Epoch 9/10... Discriminator Loss: 0.8714... Generator Loss: 2.8671
    Epoch 9/10... Discriminator Loss: 0.7056... Generator Loss: 0.9708
    Epoch 9/10... Discriminator Loss: 1.4503... Generator Loss: 0.6213
    Epoch 9/10... Discriminator Loss: 0.5519... Generator Loss: 2.4748
    Epoch 9/10... Discriminator Loss: 0.8105... Generator Loss: 3.2085
    Epoch 9/10... Discriminator Loss: 0.6208... Generator Loss: 1.1524
    Epoch 9/10... Discriminator Loss: 0.4377... Generator Loss: 1.6198
    Epoch 9/10... Discriminator Loss: 0.4695... Generator Loss: 1.3949
    Epoch 9/10... Discriminator Loss: 0.6064... Generator Loss: 1.1272
    Epoch 9/10... Discriminator Loss: 0.5819... Generator Loss: 1.0883



![png](output_23_83.png)


    Epoch 9/10... Discriminator Loss: 1.3344... Generator Loss: 0.4515
    Epoch 10/10... Discriminator Loss: 0.5075... Generator Loss: 3.0053
    Epoch 10/10... Discriminator Loss: 0.5416... Generator Loss: 3.9397
    Epoch 10/10... Discriminator Loss: 0.7364... Generator Loss: 2.0064
    Epoch 10/10... Discriminator Loss: 0.7273... Generator Loss: 1.0239
    Epoch 10/10... Discriminator Loss: 0.6292... Generator Loss: 1.0798
    Epoch 10/10... Discriminator Loss: 0.8108... Generator Loss: 3.4136
    Epoch 10/10... Discriminator Loss: 0.8334... Generator Loss: 0.8134
    Epoch 10/10... Discriminator Loss: 1.1339... Generator Loss: 0.5723
    Epoch 10/10... Discriminator Loss: 0.4887... Generator Loss: 1.3437



![png](output_23_85.png)


    Epoch 10/10... Discriminator Loss: 0.4533... Generator Loss: 1.4620
    Epoch 10/10... Discriminator Loss: 0.3826... Generator Loss: 1.5410
    Epoch 10/10... Discriminator Loss: 0.4455... Generator Loss: 1.3866
    Epoch 10/10... Discriminator Loss: 0.5488... Generator Loss: 1.1811
    Epoch 10/10... Discriminator Loss: 0.1718... Generator Loss: 2.5793
    Epoch 10/10... Discriminator Loss: 0.5716... Generator Loss: 1.2931
    Epoch 10/10... Discriminator Loss: 0.4178... Generator Loss: 1.5659
    Epoch 10/10... Discriminator Loss: 0.8617... Generator Loss: 0.9010
    Epoch 10/10... Discriminator Loss: 0.4621... Generator Loss: 1.4231
    Epoch 10/10... Discriminator Loss: 0.2120... Generator Loss: 2.2277



![png](output_23_87.png)


    Epoch 10/10... Discriminator Loss: 0.3407... Generator Loss: 1.7319
    Epoch 10/10... Discriminator Loss: 0.3888... Generator Loss: 1.5951
    Epoch 10/10... Discriminator Loss: 2.5401... Generator Loss: 0.4258
    Epoch 10/10... Discriminator Loss: 1.2512... Generator Loss: 3.7148
    Epoch 10/10... Discriminator Loss: 0.7319... Generator Loss: 2.9358
    Epoch 10/10... Discriminator Loss: 0.4781... Generator Loss: 1.4337
    Epoch 10/10... Discriminator Loss: 0.4154... Generator Loss: 2.2805
    Epoch 10/10... Discriminator Loss: 0.5122... Generator Loss: 1.4989
    Epoch 10/10... Discriminator Loss: 1.2612... Generator Loss: 0.5250
    Epoch 10/10... Discriminator Loss: 0.9790... Generator Loss: 0.8080



![png](output_23_89.png)


    Epoch 10/10... Discriminator Loss: 0.8949... Generator Loss: 0.8202
    Epoch 10/10... Discriminator Loss: 0.5393... Generator Loss: 1.3426
    Epoch 10/10... Discriminator Loss: 0.9106... Generator Loss: 0.7993
    Epoch 10/10... Discriminator Loss: 1.7793... Generator Loss: 4.7845
    Epoch 10/10... Discriminator Loss: 0.6564... Generator Loss: 1.8190
    Epoch 10/10... Discriminator Loss: 0.7534... Generator Loss: 1.0945
    Epoch 10/10... Discriminator Loss: 0.7605... Generator Loss: 1.1416
    Epoch 10/10... Discriminator Loss: 0.6249... Generator Loss: 1.2289
    Epoch 10/10... Discriminator Loss: 0.7227... Generator Loss: 1.8348
    Epoch 10/10... Discriminator Loss: 0.5677... Generator Loss: 2.2659



![png](output_23_91.png)


    Epoch 10/10... Discriminator Loss: 1.2031... Generator Loss: 4.3281
    Epoch 10/10... Discriminator Loss: 1.0804... Generator Loss: 0.7337
    Epoch 10/10... Discriminator Loss: 0.5983... Generator Loss: 1.1761
    Epoch 10/10... Discriminator Loss: 0.8926... Generator Loss: 0.8186
    Epoch 10/10... Discriminator Loss: 0.7393... Generator Loss: 0.9409
    Epoch 10/10... Discriminator Loss: 1.5410... Generator Loss: 0.6956
    Epoch 10/10... Discriminator Loss: 0.7775... Generator Loss: 0.9720
    Epoch 10/10... Discriminator Loss: 4.8464... Generator Loss: 0.0365


### CelebA
Run your GANs on CelebA.  It will take around 20 minutes on the average GPU to run one epoch.  You can run the whole epoch or stop when it starts to generate realistic faces.


```python
batch_size = 256
z_dim = 250
learning_rate = 0.001
beta1 = 0.5

"""
DON'T MODIFY ANYTHING IN THIS CELL THAT IS BELOW THIS LINE
"""
epochs = 10

celeba_dataset = helper.Dataset('celeba', glob(os.path.join(data_dir, 'img_align_celeba/*.jpg')))
with tf.Graph().as_default():
    train(epochs, batch_size, z_dim, learning_rate, beta1, celeba_dataset.get_batches,
          celeba_dataset.shape, celeba_dataset.image_mode)
```

    Epoch 1/10... Discriminator Loss: 0.8094... Generator Loss: 7.6747
    Epoch 1/10... Discriminator Loss: 0.1566... Generator Loss: 5.3145
    Epoch 1/10... Discriminator Loss: 0.5000... Generator Loss: 1.8677
    Epoch 1/10... Discriminator Loss: 1.5264... Generator Loss: 0.7504
    Epoch 1/10... Discriminator Loss: 1.0634... Generator Loss: 0.8708
    Epoch 1/10... Discriminator Loss: 1.3888... Generator Loss: 4.9941
    Epoch 1/10... Discriminator Loss: 0.5587... Generator Loss: 1.4300
    Epoch 1/10... Discriminator Loss: 1.9965... Generator Loss: 7.9802
    Epoch 1/10... Discriminator Loss: 0.3799... Generator Loss: 2.9336
    Epoch 1/10... Discriminator Loss: 0.5098... Generator Loss: 1.5290



![png](output_25_1.png)


    Epoch 1/10... Discriminator Loss: 0.3621... Generator Loss: 2.0671
    Epoch 1/10... Discriminator Loss: 0.5171... Generator Loss: 5.4507
    Epoch 1/10... Discriminator Loss: 0.4150... Generator Loss: 4.7855
    Epoch 1/10... Discriminator Loss: 2.5669... Generator Loss: 7.4096
    Epoch 1/10... Discriminator Loss: 0.8983... Generator Loss: 0.9205
    Epoch 1/10... Discriminator Loss: 0.8775... Generator Loss: 1.0431
    Epoch 1/10... Discriminator Loss: 0.6235... Generator Loss: 1.5863
    Epoch 1/10... Discriminator Loss: 0.9191... Generator Loss: 2.0956
    Epoch 1/10... Discriminator Loss: 1.8479... Generator Loss: 0.9136
    Epoch 1/10... Discriminator Loss: 1.0204... Generator Loss: 0.7392



![png](output_25_3.png)


    Epoch 1/10... Discriminator Loss: 0.9053... Generator Loss: 1.5041
    Epoch 1/10... Discriminator Loss: 1.9032... Generator Loss: 0.3838
    Epoch 1/10... Discriminator Loss: 0.9477... Generator Loss: 1.2438
    Epoch 1/10... Discriminator Loss: 5.2631... Generator Loss: 7.4679
    Epoch 1/10... Discriminator Loss: 0.8827... Generator Loss: 1.4182
    Epoch 1/10... Discriminator Loss: 0.7052... Generator Loss: 1.7534
    Epoch 1/10... Discriminator Loss: 0.9073... Generator Loss: 1.0589
    Epoch 1/10... Discriminator Loss: 0.6289... Generator Loss: 1.2499
    Epoch 1/10... Discriminator Loss: 1.9771... Generator Loss: 1.1924
    Epoch 1/10... Discriminator Loss: 1.2673... Generator Loss: 0.8023



![png](output_25_5.png)


    Epoch 1/10... Discriminator Loss: 0.9136... Generator Loss: 1.0655
    Epoch 1/10... Discriminator Loss: 1.2580... Generator Loss: 0.7414
    Epoch 1/10... Discriminator Loss: 1.3616... Generator Loss: 1.3517
    Epoch 1/10... Discriminator Loss: 1.2690... Generator Loss: 1.2334
    Epoch 1/10... Discriminator Loss: 1.4983... Generator Loss: 1.2000
    Epoch 1/10... Discriminator Loss: 1.2616... Generator Loss: 0.6805
    Epoch 1/10... Discriminator Loss: 1.3220... Generator Loss: 0.9614
    Epoch 1/10... Discriminator Loss: 1.4970... Generator Loss: 0.9714
    Epoch 1/10... Discriminator Loss: 0.8521... Generator Loss: 1.0904
    Epoch 1/10... Discriminator Loss: 1.1329... Generator Loss: 1.0144



![png](output_25_7.png)


    Epoch 1/10... Discriminator Loss: 1.1787... Generator Loss: 1.2948
    Epoch 1/10... Discriminator Loss: 0.8097... Generator Loss: 1.2133
    Epoch 1/10... Discriminator Loss: 1.6093... Generator Loss: 0.9275
    Epoch 1/10... Discriminator Loss: 1.2092... Generator Loss: 0.9608
    Epoch 1/10... Discriminator Loss: 1.4029... Generator Loss: 0.6592
    Epoch 1/10... Discriminator Loss: 1.1530... Generator Loss: 1.0856
    Epoch 1/10... Discriminator Loss: 1.0952... Generator Loss: 0.9966
    Epoch 1/10... Discriminator Loss: 0.9427... Generator Loss: 1.4016
    Epoch 1/10... Discriminator Loss: 0.7345... Generator Loss: 1.2807
    Epoch 1/10... Discriminator Loss: 1.1596... Generator Loss: 1.0239



![png](output_25_9.png)


    Epoch 1/10... Discriminator Loss: 1.5354... Generator Loss: 0.6546
    Epoch 1/10... Discriminator Loss: 1.1269... Generator Loss: 0.9089
    Epoch 1/10... Discriminator Loss: 1.2989... Generator Loss: 0.8651
    Epoch 1/10... Discriminator Loss: 1.2657... Generator Loss: 2.0071
    Epoch 1/10... Discriminator Loss: 0.9204... Generator Loss: 1.0279
    Epoch 1/10... Discriminator Loss: 1.0968... Generator Loss: 1.4535
    Epoch 1/10... Discriminator Loss: 0.6818... Generator Loss: 1.1445
    Epoch 1/10... Discriminator Loss: 0.7279... Generator Loss: 1.4021
    Epoch 1/10... Discriminator Loss: 0.8227... Generator Loss: 0.9347
    Epoch 1/10... Discriminator Loss: 1.0264... Generator Loss: 1.8090



![png](output_25_11.png)


    Epoch 1/10... Discriminator Loss: 0.9444... Generator Loss: 1.9307
    Epoch 1/10... Discriminator Loss: 0.7075... Generator Loss: 1.7250
    Epoch 1/10... Discriminator Loss: 1.8200... Generator Loss: 0.3020
    Epoch 1/10... Discriminator Loss: 1.1120... Generator Loss: 0.8620
    Epoch 1/10... Discriminator Loss: 1.1504... Generator Loss: 1.3667
    Epoch 1/10... Discriminator Loss: 0.9524... Generator Loss: 0.9179
    Epoch 1/10... Discriminator Loss: 2.1955... Generator Loss: 5.0251
    Epoch 1/10... Discriminator Loss: 1.0300... Generator Loss: 0.9219
    Epoch 1/10... Discriminator Loss: 0.6555... Generator Loss: 1.7801
    Epoch 1/10... Discriminator Loss: 0.8499... Generator Loss: 0.9041



![png](output_25_13.png)


    Epoch 1/10... Discriminator Loss: 1.3931... Generator Loss: 0.9168
    Epoch 1/10... Discriminator Loss: 1.7069... Generator Loss: 0.2555
    Epoch 1/10... Discriminator Loss: 1.0264... Generator Loss: 1.2280
    Epoch 1/10... Discriminator Loss: 1.3681... Generator Loss: 0.4921
    Epoch 1/10... Discriminator Loss: 0.8137... Generator Loss: 1.1737
    Epoch 1/10... Discriminator Loss: 1.0422... Generator Loss: 0.8455
    Epoch 1/10... Discriminator Loss: 0.5703... Generator Loss: 1.2175
    Epoch 1/10... Discriminator Loss: 1.1676... Generator Loss: 0.7707
    Epoch 1/10... Discriminator Loss: 0.9309... Generator Loss: 1.1716
    Epoch 2/10... Discriminator Loss: 1.3183... Generator Loss: 0.4992



![png](output_25_15.png)


    Epoch 2/10... Discriminator Loss: 0.9358... Generator Loss: 1.1897
    Epoch 2/10... Discriminator Loss: 1.0317... Generator Loss: 0.8532
    Epoch 2/10... Discriminator Loss: 1.5390... Generator Loss: 0.3375
    Epoch 2/10... Discriminator Loss: 1.4615... Generator Loss: 2.1470
    Epoch 2/10... Discriminator Loss: 0.8959... Generator Loss: 1.6309
    Epoch 2/10... Discriminator Loss: 0.9246... Generator Loss: 1.5012
    Epoch 2/10... Discriminator Loss: 1.1694... Generator Loss: 0.6506
    Epoch 2/10... Discriminator Loss: 1.3194... Generator Loss: 1.7736
    Epoch 2/10... Discriminator Loss: 1.0445... Generator Loss: 0.9593
    Epoch 2/10... Discriminator Loss: 0.8200... Generator Loss: 1.6414



![png](output_25_17.png)


    Epoch 2/10... Discriminator Loss: 1.3906... Generator Loss: 0.4685
    Epoch 2/10... Discriminator Loss: 1.0547... Generator Loss: 1.8249
    Epoch 2/10... Discriminator Loss: 1.1501... Generator Loss: 0.8307
    Epoch 2/10... Discriminator Loss: 1.2343... Generator Loss: 0.6908
    Epoch 2/10... Discriminator Loss: 1.5784... Generator Loss: 0.3821
    Epoch 2/10... Discriminator Loss: 1.0238... Generator Loss: 0.9375
    Epoch 2/10... Discriminator Loss: 1.0865... Generator Loss: 0.8767
    Epoch 2/10... Discriminator Loss: 0.9805... Generator Loss: 1.3196
    Epoch 2/10... Discriminator Loss: 1.0204... Generator Loss: 1.2736
    Epoch 2/10... Discriminator Loss: 1.2817... Generator Loss: 0.5250



![png](output_25_19.png)


    Epoch 2/10... Discriminator Loss: 0.9657... Generator Loss: 1.2941
    Epoch 2/10... Discriminator Loss: 0.8444... Generator Loss: 1.4501
    Epoch 2/10... Discriminator Loss: 0.9455... Generator Loss: 1.9951
    Epoch 2/10... Discriminator Loss: 0.9739... Generator Loss: 0.8620
    Epoch 2/10... Discriminator Loss: 1.2451... Generator Loss: 2.4687
    Epoch 2/10... Discriminator Loss: 1.3667... Generator Loss: 2.5494
    Epoch 2/10... Discriminator Loss: 0.9810... Generator Loss: 1.5189
    Epoch 2/10... Discriminator Loss: 1.0720... Generator Loss: 0.8788
    Epoch 2/10... Discriminator Loss: 1.5610... Generator Loss: 0.3526
    Epoch 2/10... Discriminator Loss: 0.9764... Generator Loss: 1.2364



![png](output_25_21.png)


    Epoch 2/10... Discriminator Loss: 0.9805... Generator Loss: 0.8987
    Epoch 2/10... Discriminator Loss: 1.1395... Generator Loss: 0.5992
    Epoch 2/10... Discriminator Loss: 0.9749... Generator Loss: 0.8788
    Epoch 2/10... Discriminator Loss: 1.0048... Generator Loss: 1.2454
    Epoch 2/10... Discriminator Loss: 1.0039... Generator Loss: 1.6255
    Epoch 2/10... Discriminator Loss: 0.9752... Generator Loss: 1.1850
    Epoch 2/10... Discriminator Loss: 0.9715... Generator Loss: 0.9935
    Epoch 2/10... Discriminator Loss: 1.3701... Generator Loss: 2.0318
    Epoch 2/10... Discriminator Loss: 1.1299... Generator Loss: 1.2325
    Epoch 2/10... Discriminator Loss: 1.0504... Generator Loss: 0.7837



![png](output_25_23.png)


    Epoch 2/10... Discriminator Loss: 2.4326... Generator Loss: 3.1142
    Epoch 2/10... Discriminator Loss: 1.2876... Generator Loss: 0.5114
    Epoch 2/10... Discriminator Loss: 1.4300... Generator Loss: 0.4363
    Epoch 2/10... Discriminator Loss: 0.9771... Generator Loss: 0.9884
    Epoch 2/10... Discriminator Loss: 1.1779... Generator Loss: 1.2389
    Epoch 2/10... Discriminator Loss: 1.0404... Generator Loss: 1.0595
    Epoch 2/10... Discriminator Loss: 0.9181... Generator Loss: 1.0173
    Epoch 2/10... Discriminator Loss: 0.8404... Generator Loss: 1.5178
    Epoch 2/10... Discriminator Loss: 1.0165... Generator Loss: 1.0420
    Epoch 2/10... Discriminator Loss: 1.1622... Generator Loss: 0.9724



![png](output_25_25.png)


    Epoch 2/10... Discriminator Loss: 0.9760... Generator Loss: 0.9865
    Epoch 2/10... Discriminator Loss: 1.1234... Generator Loss: 1.4201
    Epoch 2/10... Discriminator Loss: 0.8361... Generator Loss: 1.3179
    Epoch 2/10... Discriminator Loss: 0.9797... Generator Loss: 1.5001
    Epoch 2/10... Discriminator Loss: 0.8701... Generator Loss: 1.6916
    Epoch 2/10... Discriminator Loss: 1.1603... Generator Loss: 0.6404
    Epoch 2/10... Discriminator Loss: 0.9757... Generator Loss: 1.2782
    Epoch 2/10... Discriminator Loss: 0.9122... Generator Loss: 1.0976
    Epoch 2/10... Discriminator Loss: 1.0536... Generator Loss: 0.9048
    Epoch 2/10... Discriminator Loss: 1.5068... Generator Loss: 2.0108



![png](output_25_27.png)


    Epoch 2/10... Discriminator Loss: 1.1399... Generator Loss: 1.3635
    Epoch 2/10... Discriminator Loss: 1.0924... Generator Loss: 0.6752
    Epoch 2/10... Discriminator Loss: 1.0974... Generator Loss: 0.6549
    Epoch 2/10... Discriminator Loss: 1.6216... Generator Loss: 0.3227
    Epoch 2/10... Discriminator Loss: 1.2196... Generator Loss: 1.3903
    Epoch 2/10... Discriminator Loss: 1.7521... Generator Loss: 0.2811
    Epoch 2/10... Discriminator Loss: 1.1230... Generator Loss: 0.9058
    Epoch 2/10... Discriminator Loss: 1.0804... Generator Loss: 0.8377
    Epoch 2/10... Discriminator Loss: 1.3447... Generator Loss: 0.5218
    Epoch 2/10... Discriminator Loss: 0.9547... Generator Loss: 1.6947



![png](output_25_29.png)


    Epoch 2/10... Discriminator Loss: 1.0263... Generator Loss: 0.7741
    Epoch 2/10... Discriminator Loss: 1.3572... Generator Loss: 0.5335
    Epoch 2/10... Discriminator Loss: 0.8878... Generator Loss: 1.7732
    Epoch 2/10... Discriminator Loss: 0.9500... Generator Loss: 1.0734
    Epoch 2/10... Discriminator Loss: 1.0769... Generator Loss: 1.3520
    Epoch 2/10... Discriminator Loss: 1.0252... Generator Loss: 1.1994
    Epoch 2/10... Discriminator Loss: 1.9886... Generator Loss: 3.4464
    Epoch 2/10... Discriminator Loss: 1.0990... Generator Loss: 1.1719
    Epoch 3/10... Discriminator Loss: 0.9002... Generator Loss: 1.1834
    Epoch 3/10... Discriminator Loss: 1.4421... Generator Loss: 0.4455



![png](output_25_31.png)


    Epoch 3/10... Discriminator Loss: 1.0823... Generator Loss: 1.4938
    Epoch 3/10... Discriminator Loss: 1.1275... Generator Loss: 0.7715
    Epoch 3/10... Discriminator Loss: 0.8282... Generator Loss: 1.2822
    Epoch 3/10... Discriminator Loss: 1.5292... Generator Loss: 2.5813
    Epoch 3/10... Discriminator Loss: 1.2807... Generator Loss: 0.5600
    Epoch 3/10... Discriminator Loss: 0.8247... Generator Loss: 1.2515
    Epoch 3/10... Discriminator Loss: 0.8830... Generator Loss: 0.9476
    Epoch 3/10... Discriminator Loss: 1.0497... Generator Loss: 1.2481
    Epoch 3/10... Discriminator Loss: 1.1220... Generator Loss: 0.6462
    Epoch 3/10... Discriminator Loss: 1.1472... Generator Loss: 0.7256



![png](output_25_33.png)


    Epoch 3/10... Discriminator Loss: 0.9394... Generator Loss: 1.1778
    Epoch 3/10... Discriminator Loss: 0.9975... Generator Loss: 0.9679
    Epoch 3/10... Discriminator Loss: 1.0468... Generator Loss: 0.8873
    Epoch 3/10... Discriminator Loss: 0.9413... Generator Loss: 1.0473
    Epoch 3/10... Discriminator Loss: 0.9703... Generator Loss: 1.1705
    Epoch 3/10... Discriminator Loss: 0.8173... Generator Loss: 1.6586
    Epoch 3/10... Discriminator Loss: 0.8461... Generator Loss: 1.1032
    Epoch 3/10... Discriminator Loss: 1.1035... Generator Loss: 0.8993
    Epoch 3/10... Discriminator Loss: 0.8210... Generator Loss: 1.4507
    Epoch 3/10... Discriminator Loss: 1.3883... Generator Loss: 2.2900



![png](output_25_35.png)


    Epoch 3/10... Discriminator Loss: 1.2950... Generator Loss: 0.5553
    Epoch 3/10... Discriminator Loss: 0.9923... Generator Loss: 1.8812
    Epoch 3/10... Discriminator Loss: 0.8956... Generator Loss: 0.8927
    Epoch 3/10... Discriminator Loss: 0.8596... Generator Loss: 1.4225
    Epoch 3/10... Discriminator Loss: 1.2003... Generator Loss: 2.1712
    Epoch 3/10... Discriminator Loss: 1.0839... Generator Loss: 1.1716
    Epoch 3/10... Discriminator Loss: 1.0480... Generator Loss: 1.6394
    Epoch 3/10... Discriminator Loss: 1.0026... Generator Loss: 1.6290
    Epoch 3/10... Discriminator Loss: 0.9128... Generator Loss: 1.1238
    Epoch 3/10... Discriminator Loss: 0.7660... Generator Loss: 1.3156



![png](output_25_37.png)


    Epoch 3/10... Discriminator Loss: 1.3118... Generator Loss: 0.5028
    Epoch 3/10... Discriminator Loss: 1.0200... Generator Loss: 1.5802
    Epoch 3/10... Discriminator Loss: 0.9884... Generator Loss: 0.8619
    Epoch 3/10... Discriminator Loss: 1.0809... Generator Loss: 1.0355
    Epoch 3/10... Discriminator Loss: 0.8533... Generator Loss: 1.1893
    Epoch 3/10... Discriminator Loss: 0.9551... Generator Loss: 0.8257
    Epoch 3/10... Discriminator Loss: 1.0167... Generator Loss: 1.6579
    Epoch 3/10... Discriminator Loss: 1.8144... Generator Loss: 0.2546
    Epoch 3/10... Discriminator Loss: 0.9123... Generator Loss: 1.1015
    Epoch 3/10... Discriminator Loss: 1.0625... Generator Loss: 1.9528



![png](output_25_39.png)


    Epoch 3/10... Discriminator Loss: 1.1810... Generator Loss: 0.5861
    Epoch 3/10... Discriminator Loss: 1.1051... Generator Loss: 0.5750
    Epoch 3/10... Discriminator Loss: 1.2392... Generator Loss: 2.6319
    Epoch 3/10... Discriminator Loss: 0.9305... Generator Loss: 1.2261
    Epoch 3/10... Discriminator Loss: 0.8642... Generator Loss: 1.0533
    Epoch 3/10... Discriminator Loss: 1.9322... Generator Loss: 0.2131
    Epoch 3/10... Discriminator Loss: 1.0063... Generator Loss: 0.9138
    Epoch 3/10... Discriminator Loss: 0.9601... Generator Loss: 1.3760
    Epoch 3/10... Discriminator Loss: 1.1878... Generator Loss: 0.6145
    Epoch 3/10... Discriminator Loss: 1.0836... Generator Loss: 0.7074



![png](output_25_41.png)


    Epoch 3/10... Discriminator Loss: 1.1628... Generator Loss: 1.0093
    Epoch 3/10... Discriminator Loss: 0.9941... Generator Loss: 1.2302
    Epoch 3/10... Discriminator Loss: 0.9627... Generator Loss: 1.0037
    Epoch 3/10... Discriminator Loss: 1.2437... Generator Loss: 2.5920
    Epoch 3/10... Discriminator Loss: 1.0917... Generator Loss: 0.6351
    Epoch 3/10... Discriminator Loss: 1.0261... Generator Loss: 0.9514
    Epoch 3/10... Discriminator Loss: 1.1383... Generator Loss: 1.8580
    Epoch 3/10... Discriminator Loss: 1.0502... Generator Loss: 0.7461
    Epoch 3/10... Discriminator Loss: 1.9887... Generator Loss: 0.2399
    Epoch 3/10... Discriminator Loss: 0.8250... Generator Loss: 1.2905



![png](output_25_43.png)


    Epoch 3/10... Discriminator Loss: 1.0343... Generator Loss: 0.9088
    Epoch 3/10... Discriminator Loss: 1.1269... Generator Loss: 1.6036
    Epoch 3/10... Discriminator Loss: 0.9804... Generator Loss: 0.8442
    Epoch 3/10... Discriminator Loss: 0.9399... Generator Loss: 1.1354
    Epoch 3/10... Discriminator Loss: 1.0650... Generator Loss: 0.7341
    Epoch 3/10... Discriminator Loss: 1.2560... Generator Loss: 0.5057
    Epoch 3/10... Discriminator Loss: 1.0505... Generator Loss: 1.3388
    Epoch 3/10... Discriminator Loss: 1.1325... Generator Loss: 0.7277
    Epoch 3/10... Discriminator Loss: 1.4262... Generator Loss: 0.3986
    Epoch 3/10... Discriminator Loss: 1.0484... Generator Loss: 0.8046



![png](output_25_45.png)


    Epoch 3/10... Discriminator Loss: 1.0581... Generator Loss: 2.3280
    Epoch 3/10... Discriminator Loss: 1.1267... Generator Loss: 0.6373
    Epoch 3/10... Discriminator Loss: 1.2202... Generator Loss: 0.5462
    Epoch 3/10... Discriminator Loss: 0.9479... Generator Loss: 0.9532
    Epoch 3/10... Discriminator Loss: 1.0625... Generator Loss: 1.3392
    Epoch 3/10... Discriminator Loss: 1.1531... Generator Loss: 2.2081
    Epoch 3/10... Discriminator Loss: 1.1164... Generator Loss: 0.6339
    Epoch 4/10... Discriminator Loss: 1.4077... Generator Loss: 0.4319
    Epoch 4/10... Discriminator Loss: 1.1939... Generator Loss: 0.5553
    Epoch 4/10... Discriminator Loss: 1.1802... Generator Loss: 0.7742



![png](output_25_47.png)


    Epoch 4/10... Discriminator Loss: 0.9705... Generator Loss: 1.3107
    Epoch 4/10... Discriminator Loss: 1.0037... Generator Loss: 1.3287
    Epoch 4/10... Discriminator Loss: 1.0121... Generator Loss: 1.5760
    Epoch 4/10... Discriminator Loss: 1.2588... Generator Loss: 0.6264
    Epoch 4/10... Discriminator Loss: 1.4000... Generator Loss: 0.4950
    Epoch 4/10... Discriminator Loss: 0.9906... Generator Loss: 1.4378
    Epoch 4/10... Discriminator Loss: 0.9248... Generator Loss: 1.1500
    Epoch 4/10... Discriminator Loss: 0.8414... Generator Loss: 1.3678
    Epoch 4/10... Discriminator Loss: 1.1442... Generator Loss: 0.6314
    Epoch 4/10... Discriminator Loss: 1.1661... Generator Loss: 1.0366



![png](output_25_49.png)


    Epoch 4/10... Discriminator Loss: 1.1054... Generator Loss: 0.6984
    Epoch 4/10... Discriminator Loss: 1.2332... Generator Loss: 0.6220
    Epoch 4/10... Discriminator Loss: 1.2010... Generator Loss: 0.9841
    Epoch 4/10... Discriminator Loss: 1.1669... Generator Loss: 0.7122
    Epoch 4/10... Discriminator Loss: 0.9824... Generator Loss: 1.0754
    Epoch 4/10... Discriminator Loss: 1.3331... Generator Loss: 0.4902
    Epoch 4/10... Discriminator Loss: 0.9894... Generator Loss: 0.8781
    Epoch 4/10... Discriminator Loss: 1.1012... Generator Loss: 0.7336
    Epoch 4/10... Discriminator Loss: 1.0646... Generator Loss: 1.3069
    Epoch 4/10... Discriminator Loss: 0.9395... Generator Loss: 1.1646



![png](output_25_51.png)


    Epoch 4/10... Discriminator Loss: 0.9026... Generator Loss: 1.4994
    Epoch 4/10... Discriminator Loss: 1.0078... Generator Loss: 0.9334
    Epoch 4/10... Discriminator Loss: 1.2467... Generator Loss: 0.5996
    Epoch 4/10... Discriminator Loss: 1.1669... Generator Loss: 0.5427
    Epoch 4/10... Discriminator Loss: 1.0463... Generator Loss: 0.7078
    Epoch 4/10... Discriminator Loss: 1.1661... Generator Loss: 1.2043
    Epoch 4/10... Discriminator Loss: 1.4052... Generator Loss: 0.4387
    Epoch 4/10... Discriminator Loss: 0.8741... Generator Loss: 1.1328
    Epoch 4/10... Discriminator Loss: 1.0942... Generator Loss: 0.8124
    Epoch 4/10... Discriminator Loss: 1.9644... Generator Loss: 3.0399



![png](output_25_53.png)


    Epoch 4/10... Discriminator Loss: 1.3757... Generator Loss: 0.4661
    Epoch 4/10... Discriminator Loss: 1.1934... Generator Loss: 1.3779
    Epoch 4/10... Discriminator Loss: 1.3671... Generator Loss: 0.4823
    Epoch 4/10... Discriminator Loss: 1.0559... Generator Loss: 0.9699
    Epoch 4/10... Discriminator Loss: 1.0802... Generator Loss: 2.2092
    Epoch 4/10... Discriminator Loss: 1.1239... Generator Loss: 1.0506
    Epoch 4/10... Discriminator Loss: 0.8855... Generator Loss: 1.2484
    Epoch 4/10... Discriminator Loss: 1.2028... Generator Loss: 1.7964
    Epoch 4/10... Discriminator Loss: 1.2831... Generator Loss: 0.5204
    Epoch 4/10... Discriminator Loss: 1.3475... Generator Loss: 0.4499



![png](output_25_55.png)


    Epoch 4/10... Discriminator Loss: 1.0290... Generator Loss: 1.1513
    Epoch 4/10... Discriminator Loss: 1.0484... Generator Loss: 1.0776
    Epoch 4/10... Discriminator Loss: 1.2459... Generator Loss: 0.7133
    Epoch 4/10... Discriminator Loss: 1.4109... Generator Loss: 0.4125
    Epoch 4/10... Discriminator Loss: 1.2133... Generator Loss: 1.1796
    Epoch 4/10... Discriminator Loss: 1.1709... Generator Loss: 1.2815
    Epoch 4/10... Discriminator Loss: 1.2028... Generator Loss: 0.5675
    Epoch 4/10... Discriminator Loss: 0.9588... Generator Loss: 1.2172
    Epoch 4/10... Discriminator Loss: 1.1927... Generator Loss: 0.6159
    Epoch 4/10... Discriminator Loss: 0.9898... Generator Loss: 1.4901



![png](output_25_57.png)


    Epoch 4/10... Discriminator Loss: 1.2574... Generator Loss: 0.8690
    Epoch 4/10... Discriminator Loss: 1.2041... Generator Loss: 1.0482
    Epoch 4/10... Discriminator Loss: 1.2230... Generator Loss: 0.5421
    Epoch 4/10... Discriminator Loss: 1.2473... Generator Loss: 0.5935
    Epoch 4/10... Discriminator Loss: 1.0838... Generator Loss: 0.7181
    Epoch 4/10... Discriminator Loss: 1.6285... Generator Loss: 0.3233
    Epoch 4/10... Discriminator Loss: 1.2573... Generator Loss: 0.9961
    Epoch 4/10... Discriminator Loss: 1.0281... Generator Loss: 0.7864
    Epoch 4/10... Discriminator Loss: 1.2642... Generator Loss: 0.5295
    Epoch 4/10... Discriminator Loss: 1.0936... Generator Loss: 1.1874



![png](output_25_59.png)


    Epoch 4/10... Discriminator Loss: 1.1806... Generator Loss: 1.2133
    Epoch 4/10... Discriminator Loss: 1.2790... Generator Loss: 0.6908
    Epoch 4/10... Discriminator Loss: 1.0150... Generator Loss: 1.3363
    Epoch 4/10... Discriminator Loss: 1.0315... Generator Loss: 1.2204
    Epoch 4/10... Discriminator Loss: 1.0889... Generator Loss: 0.7608
    Epoch 4/10... Discriminator Loss: 1.0745... Generator Loss: 1.5400
    Epoch 4/10... Discriminator Loss: 1.1698... Generator Loss: 0.5684
    Epoch 4/10... Discriminator Loss: 1.0531... Generator Loss: 0.9459
    Epoch 4/10... Discriminator Loss: 1.0996... Generator Loss: 0.7973
    Epoch 4/10... Discriminator Loss: 1.3090... Generator Loss: 1.5828



![png](output_25_61.png)


    Epoch 4/10... Discriminator Loss: 1.0662... Generator Loss: 0.8680
    Epoch 4/10... Discriminator Loss: 1.1211... Generator Loss: 1.3670
    Epoch 4/10... Discriminator Loss: 1.2375... Generator Loss: 0.5555
    Epoch 4/10... Discriminator Loss: 1.6811... Generator Loss: 0.2759
    Epoch 4/10... Discriminator Loss: 1.0288... Generator Loss: 1.0061
    Epoch 4/10... Discriminator Loss: 1.1978... Generator Loss: 1.5572
    Epoch 5/10... Discriminator Loss: 1.0735... Generator Loss: 0.9140
    Epoch 5/10... Discriminator Loss: 1.6038... Generator Loss: 2.5424
    Epoch 5/10... Discriminator Loss: 1.2779... Generator Loss: 1.6362
    Epoch 5/10... Discriminator Loss: 1.1936... Generator Loss: 1.0424



![png](output_25_63.png)


    Epoch 5/10... Discriminator Loss: 1.2835... Generator Loss: 0.6490
    Epoch 5/10... Discriminator Loss: 1.2591... Generator Loss: 1.8241
    Epoch 5/10... Discriminator Loss: 1.0284... Generator Loss: 1.5940
    Epoch 5/10... Discriminator Loss: 1.0798... Generator Loss: 1.5756
    Epoch 5/10... Discriminator Loss: 1.3380... Generator Loss: 0.4841
    Epoch 5/10... Discriminator Loss: 1.1376... Generator Loss: 1.2950
    Epoch 5/10... Discriminator Loss: 1.1169... Generator Loss: 1.0165
    Epoch 5/10... Discriminator Loss: 1.0845... Generator Loss: 0.7568
    Epoch 5/10... Discriminator Loss: 1.0657... Generator Loss: 0.9017
    Epoch 5/10... Discriminator Loss: 1.1946... Generator Loss: 0.6104



![png](output_25_65.png)


    Epoch 5/10... Discriminator Loss: 1.0758... Generator Loss: 1.2627
    Epoch 5/10... Discriminator Loss: 1.1442... Generator Loss: 1.2468
    Epoch 5/10... Discriminator Loss: 1.1044... Generator Loss: 1.0167
    Epoch 5/10... Discriminator Loss: 1.0286... Generator Loss: 0.9856
    Epoch 5/10... Discriminator Loss: 1.0144... Generator Loss: 1.3014
    Epoch 5/10... Discriminator Loss: 1.5845... Generator Loss: 1.6425
    Epoch 5/10... Discriminator Loss: 1.0718... Generator Loss: 1.6003
    Epoch 5/10... Discriminator Loss: 1.4203... Generator Loss: 1.1885
    Epoch 5/10... Discriminator Loss: 1.4738... Generator Loss: 1.8060
    Epoch 5/10... Discriminator Loss: 1.5510... Generator Loss: 0.3605



![png](output_25_67.png)


    Epoch 5/10... Discriminator Loss: 0.9390... Generator Loss: 0.7193
    Epoch 5/10... Discriminator Loss: 1.1823... Generator Loss: 0.9911
    Epoch 5/10... Discriminator Loss: 1.1030... Generator Loss: 0.8006
    Epoch 5/10... Discriminator Loss: 1.0080... Generator Loss: 0.7848
    Epoch 5/10... Discriminator Loss: 1.4492... Generator Loss: 0.4526
    Epoch 5/10... Discriminator Loss: 1.2487... Generator Loss: 0.4947
    Epoch 5/10... Discriminator Loss: 1.1941... Generator Loss: 1.4465
    Epoch 5/10... Discriminator Loss: 1.2910... Generator Loss: 0.5022
    Epoch 5/10... Discriminator Loss: 0.9722... Generator Loss: 0.8487
    Epoch 5/10... Discriminator Loss: 1.1843... Generator Loss: 0.9010



![png](output_25_69.png)


    Epoch 5/10... Discriminator Loss: 1.1771... Generator Loss: 0.6591
    Epoch 5/10... Discriminator Loss: 1.1168... Generator Loss: 1.6293
    Epoch 5/10... Discriminator Loss: 1.4778... Generator Loss: 0.5399
    Epoch 5/10... Discriminator Loss: 1.6713... Generator Loss: 2.1004
    Epoch 5/10... Discriminator Loss: 1.1654... Generator Loss: 0.8423
    Epoch 5/10... Discriminator Loss: 1.1772... Generator Loss: 1.2760
    Epoch 5/10... Discriminator Loss: 1.0853... Generator Loss: 1.4113
    Epoch 5/10... Discriminator Loss: 1.2640... Generator Loss: 1.4443
    Epoch 5/10... Discriminator Loss: 1.1544... Generator Loss: 1.3576
    Epoch 5/10... Discriminator Loss: 1.0646... Generator Loss: 1.7733



![png](output_25_71.png)


    Epoch 5/10... Discriminator Loss: 1.3437... Generator Loss: 0.7198
    Epoch 5/10... Discriminator Loss: 0.9991... Generator Loss: 1.1178
    Epoch 5/10... Discriminator Loss: 1.0195... Generator Loss: 0.8129
    Epoch 5/10... Discriminator Loss: 1.2966... Generator Loss: 1.3738
    Epoch 5/10... Discriminator Loss: 1.2502... Generator Loss: 0.6016
    Epoch 5/10... Discriminator Loss: 1.1315... Generator Loss: 0.8801
    Epoch 5/10... Discriminator Loss: 1.0168... Generator Loss: 0.8151
    Epoch 5/10... Discriminator Loss: 1.0413... Generator Loss: 0.7593
    Epoch 5/10... Discriminator Loss: 1.2578... Generator Loss: 0.7015
    Epoch 5/10... Discriminator Loss: 1.6243... Generator Loss: 1.8210



![png](output_25_73.png)


    Epoch 5/10... Discriminator Loss: 1.4409... Generator Loss: 0.4223
    Epoch 5/10... Discriminator Loss: 1.0058... Generator Loss: 1.1395
    Epoch 5/10... Discriminator Loss: 1.3128... Generator Loss: 1.3750
    Epoch 5/10... Discriminator Loss: 0.9896... Generator Loss: 0.9287
    Epoch 5/10... Discriminator Loss: 1.1374... Generator Loss: 1.3242
    Epoch 5/10... Discriminator Loss: 1.1258... Generator Loss: 1.0416
    Epoch 5/10... Discriminator Loss: 1.4676... Generator Loss: 1.8702
    Epoch 5/10... Discriminator Loss: 1.3858... Generator Loss: 1.1097
    Epoch 5/10... Discriminator Loss: 1.1856... Generator Loss: 0.9677
    Epoch 5/10... Discriminator Loss: 1.1296... Generator Loss: 0.7642



![png](output_25_75.png)


    Epoch 5/10... Discriminator Loss: 1.2148... Generator Loss: 0.6996
    Epoch 5/10... Discriminator Loss: 1.1777... Generator Loss: 0.5954
    Epoch 5/10... Discriminator Loss: 1.2432... Generator Loss: 0.8375
    Epoch 5/10... Discriminator Loss: 1.2497... Generator Loss: 0.5883
    Epoch 5/10... Discriminator Loss: 1.3520... Generator Loss: 0.4499
    Epoch 5/10... Discriminator Loss: 1.1502... Generator Loss: 1.3021
    Epoch 5/10... Discriminator Loss: 1.6081... Generator Loss: 0.3378
    Epoch 5/10... Discriminator Loss: 0.9676... Generator Loss: 0.9668
    Epoch 5/10... Discriminator Loss: 1.5259... Generator Loss: 2.4370
    Epoch 5/10... Discriminator Loss: 0.9722... Generator Loss: 0.9575



![png](output_25_77.png)


    Epoch 5/10... Discriminator Loss: 1.1237... Generator Loss: 1.0570
    Epoch 5/10... Discriminator Loss: 1.2953... Generator Loss: 1.1436
    Epoch 5/10... Discriminator Loss: 1.4155... Generator Loss: 0.5683
    Epoch 5/10... Discriminator Loss: 1.5185... Generator Loss: 0.3678
    Epoch 5/10... Discriminator Loss: 1.1521... Generator Loss: 1.0430
    Epoch 6/10... Discriminator Loss: 1.3168... Generator Loss: 0.8890
    Epoch 6/10... Discriminator Loss: 1.4418... Generator Loss: 0.3961
    Epoch 6/10... Discriminator Loss: 1.1244... Generator Loss: 1.1091
    Epoch 6/10... Discriminator Loss: 1.1278... Generator Loss: 0.7884
    Epoch 6/10... Discriminator Loss: 1.1513... Generator Loss: 0.7956



![png](output_25_79.png)


    Epoch 6/10... Discriminator Loss: 1.4297... Generator Loss: 0.3896
    Epoch 6/10... Discriminator Loss: 1.2733... Generator Loss: 0.6201
    Epoch 6/10... Discriminator Loss: 1.1660... Generator Loss: 0.8435
    Epoch 6/10... Discriminator Loss: 1.6955... Generator Loss: 1.7278
    Epoch 6/10... Discriminator Loss: 1.1971... Generator Loss: 0.6336
    Epoch 6/10... Discriminator Loss: 1.0984... Generator Loss: 0.6329
    Epoch 6/10... Discriminator Loss: 0.9751... Generator Loss: 1.2244
    Epoch 6/10... Discriminator Loss: 1.0807... Generator Loss: 0.8332
    Epoch 6/10... Discriminator Loss: 1.0547... Generator Loss: 0.6920
    Epoch 6/10... Discriminator Loss: 0.9994... Generator Loss: 0.6329



![png](output_25_81.png)


    Epoch 6/10... Discriminator Loss: 1.5111... Generator Loss: 0.3680
    Epoch 6/10... Discriminator Loss: 1.0807... Generator Loss: 1.1308
    Epoch 6/10... Discriminator Loss: 1.1633... Generator Loss: 1.4606
    Epoch 6/10... Discriminator Loss: 1.2321... Generator Loss: 1.3833
    Epoch 6/10... Discriminator Loss: 0.9297... Generator Loss: 1.7394
    Epoch 6/10... Discriminator Loss: 1.2401... Generator Loss: 0.6583
    Epoch 6/10... Discriminator Loss: 1.0641... Generator Loss: 1.0907
    Epoch 6/10... Discriminator Loss: 1.1917... Generator Loss: 0.7920
    Epoch 6/10... Discriminator Loss: 1.1710... Generator Loss: 0.6937
    Epoch 6/10... Discriminator Loss: 1.1123... Generator Loss: 1.3643



![png](output_25_83.png)


    Epoch 6/10... Discriminator Loss: 1.5537... Generator Loss: 0.4532
    Epoch 6/10... Discriminator Loss: 1.4631... Generator Loss: 1.8262
    Epoch 6/10... Discriminator Loss: 0.9736... Generator Loss: 0.7487
    Epoch 6/10... Discriminator Loss: 1.4152... Generator Loss: 1.3025
    Epoch 6/10... Discriminator Loss: 1.2280... Generator Loss: 0.5227
    Epoch 6/10... Discriminator Loss: 1.0215... Generator Loss: 0.7804
    Epoch 6/10... Discriminator Loss: 1.2424... Generator Loss: 0.5696
    Epoch 6/10... Discriminator Loss: 1.3902... Generator Loss: 0.4742
    Epoch 6/10... Discriminator Loss: 1.2701... Generator Loss: 1.7693
    Epoch 6/10... Discriminator Loss: 1.6219... Generator Loss: 1.7302



![png](output_25_85.png)


    Epoch 6/10... Discriminator Loss: 1.1274... Generator Loss: 1.2118
    Epoch 6/10... Discriminator Loss: 0.9455... Generator Loss: 0.9583
    Epoch 6/10... Discriminator Loss: 1.0683... Generator Loss: 1.3907
    Epoch 6/10... Discriminator Loss: 1.0726... Generator Loss: 0.7548
    Epoch 6/10... Discriminator Loss: 0.8280... Generator Loss: 1.4448
    Epoch 6/10... Discriminator Loss: 0.9924... Generator Loss: 0.6969
    Epoch 6/10... Discriminator Loss: 1.3533... Generator Loss: 0.4087
    Epoch 6/10... Discriminator Loss: 1.3131... Generator Loss: 0.8922
    Epoch 6/10... Discriminator Loss: 1.3234... Generator Loss: 0.5957
    Epoch 6/10... Discriminator Loss: 1.0817... Generator Loss: 0.9626



![png](output_25_87.png)


    Epoch 6/10... Discriminator Loss: 1.4059... Generator Loss: 0.7034
    Epoch 6/10... Discriminator Loss: 1.1241... Generator Loss: 0.7853
    Epoch 6/10... Discriminator Loss: 0.9187... Generator Loss: 1.2918
    Epoch 6/10... Discriminator Loss: 0.9023... Generator Loss: 0.9883
    Epoch 6/10... Discriminator Loss: 1.4491... Generator Loss: 0.4124
    Epoch 6/10... Discriminator Loss: 1.0704... Generator Loss: 0.6462
    Epoch 6/10... Discriminator Loss: 1.1236... Generator Loss: 0.9981
    Epoch 6/10... Discriminator Loss: 1.2570... Generator Loss: 2.0281
    Epoch 6/10... Discriminator Loss: 0.8443... Generator Loss: 2.2462
    Epoch 6/10... Discriminator Loss: 1.2749... Generator Loss: 0.6501



![png](output_25_89.png)


    Epoch 6/10... Discriminator Loss: 1.2722... Generator Loss: 0.9125
    Epoch 6/10... Discriminator Loss: 1.3024... Generator Loss: 1.3557
    Epoch 6/10... Discriminator Loss: 0.9862... Generator Loss: 0.8669
    Epoch 6/10... Discriminator Loss: 1.4053... Generator Loss: 0.5155
    Epoch 6/10... Discriminator Loss: 1.2155... Generator Loss: 1.6595
    Epoch 6/10... Discriminator Loss: 1.7692... Generator Loss: 0.3252
    Epoch 6/10... Discriminator Loss: 1.1750... Generator Loss: 0.8707
    Epoch 6/10... Discriminator Loss: 1.6511... Generator Loss: 0.3069
    Epoch 6/10... Discriminator Loss: 1.1735... Generator Loss: 0.9678
    Epoch 6/10... Discriminator Loss: 1.0846... Generator Loss: 0.9991



![png](output_25_91.png)


    Epoch 6/10... Discriminator Loss: 0.9368... Generator Loss: 0.7432
    Epoch 6/10... Discriminator Loss: 1.1939... Generator Loss: 0.9940
    Epoch 6/10... Discriminator Loss: 1.1582... Generator Loss: 0.7253
    Epoch 6/10... Discriminator Loss: 1.3371... Generator Loss: 1.5790
    Epoch 6/10... Discriminator Loss: 1.7231... Generator Loss: 0.3145
    Epoch 6/10... Discriminator Loss: 0.9051... Generator Loss: 1.6423
    Epoch 6/10... Discriminator Loss: 1.1495... Generator Loss: 0.6175
    Epoch 6/10... Discriminator Loss: 1.2838... Generator Loss: 0.7158
    Epoch 6/10... Discriminator Loss: 1.4209... Generator Loss: 1.4435
    Epoch 6/10... Discriminator Loss: 1.4033... Generator Loss: 0.3777



![png](output_25_93.png)


    Epoch 6/10... Discriminator Loss: 1.2088... Generator Loss: 0.5783
    Epoch 6/10... Discriminator Loss: 1.1283... Generator Loss: 0.8129
    Epoch 6/10... Discriminator Loss: 1.2505... Generator Loss: 1.0957
    Epoch 6/10... Discriminator Loss: 1.6598... Generator Loss: 0.4461
    Epoch 7/10... Discriminator Loss: 1.4414... Generator Loss: 0.6195
    Epoch 7/10... Discriminator Loss: 0.8999... Generator Loss: 0.9769
    Epoch 7/10... Discriminator Loss: 1.2932... Generator Loss: 0.8462
    Epoch 7/10... Discriminator Loss: 0.7468... Generator Loss: 1.9239
    Epoch 7/10... Discriminator Loss: 1.3138... Generator Loss: 0.4945
    Epoch 7/10... Discriminator Loss: 1.1195... Generator Loss: 0.8099



![png](output_25_95.png)


    Epoch 7/10... Discriminator Loss: 1.0290... Generator Loss: 0.8514
    Epoch 7/10... Discriminator Loss: 0.8674... Generator Loss: 2.2232
    Epoch 7/10... Discriminator Loss: 1.1783... Generator Loss: 0.6641
    Epoch 7/10... Discriminator Loss: 0.8197... Generator Loss: 1.3480
    Epoch 7/10... Discriminator Loss: 1.0502... Generator Loss: 1.2292
    Epoch 7/10... Discriminator Loss: 1.1108... Generator Loss: 1.0514
    Epoch 7/10... Discriminator Loss: 1.1595... Generator Loss: 0.6939
    Epoch 7/10... Discriminator Loss: 1.5679... Generator Loss: 0.4260
    Epoch 7/10... Discriminator Loss: 1.3585... Generator Loss: 0.6388
    Epoch 7/10... Discriminator Loss: 1.2730... Generator Loss: 1.2236



![png](output_25_97.png)


    Epoch 7/10... Discriminator Loss: 1.0971... Generator Loss: 0.9475
    Epoch 7/10... Discriminator Loss: 1.0958... Generator Loss: 0.8661
    Epoch 7/10... Discriminator Loss: 1.6535... Generator Loss: 0.3106
    Epoch 7/10... Discriminator Loss: 0.8786... Generator Loss: 1.8012
    Epoch 7/10... Discriminator Loss: 1.2174... Generator Loss: 1.1538
    Epoch 7/10... Discriminator Loss: 1.1396... Generator Loss: 0.7075
    Epoch 7/10... Discriminator Loss: 1.1344... Generator Loss: 0.9386
    Epoch 7/10... Discriminator Loss: 1.1348... Generator Loss: 1.1712
    Epoch 7/10... Discriminator Loss: 1.5182... Generator Loss: 0.4048
    Epoch 7/10... Discriminator Loss: 1.2574... Generator Loss: 1.2386



![png](output_25_99.png)


    Epoch 7/10... Discriminator Loss: 1.5190... Generator Loss: 0.4053
    Epoch 7/10... Discriminator Loss: 0.9479... Generator Loss: 0.9024
    Epoch 7/10... Discriminator Loss: 1.1931... Generator Loss: 1.0626
    Epoch 7/10... Discriminator Loss: 1.1007... Generator Loss: 0.6397
    Epoch 7/10... Discriminator Loss: 1.5853... Generator Loss: 3.1527
    Epoch 7/10... Discriminator Loss: 1.1973... Generator Loss: 0.8628
    Epoch 7/10... Discriminator Loss: 1.3965... Generator Loss: 0.5661
    Epoch 7/10... Discriminator Loss: 1.0290... Generator Loss: 1.0188
    Epoch 7/10... Discriminator Loss: 1.2544... Generator Loss: 0.5719
    Epoch 7/10... Discriminator Loss: 1.4922... Generator Loss: 0.7302



![png](output_25_101.png)


    Epoch 7/10... Discriminator Loss: 1.0546... Generator Loss: 1.2299
    Epoch 7/10... Discriminator Loss: 1.1929... Generator Loss: 0.8691
    Epoch 7/10... Discriminator Loss: 1.2212... Generator Loss: 1.9874
    Epoch 7/10... Discriminator Loss: 1.3023... Generator Loss: 0.7576
    Epoch 7/10... Discriminator Loss: 1.0416... Generator Loss: 1.3005
    Epoch 7/10... Discriminator Loss: 1.1602... Generator Loss: 0.7853
    Epoch 7/10... Discriminator Loss: 2.1136... Generator Loss: 2.7222
    Epoch 7/10... Discriminator Loss: 1.5259... Generator Loss: 0.4253
    Epoch 7/10... Discriminator Loss: 1.2805... Generator Loss: 0.8586
    Epoch 7/10... Discriminator Loss: 0.8252... Generator Loss: 1.3997



![png](output_25_103.png)


    Epoch 7/10... Discriminator Loss: 1.3378... Generator Loss: 0.5799
    Epoch 7/10... Discriminator Loss: 1.8776... Generator Loss: 0.9037
    Epoch 7/10... Discriminator Loss: 1.2435... Generator Loss: 0.5305
    Epoch 7/10... Discriminator Loss: 1.1723... Generator Loss: 0.6196
    Epoch 7/10... Discriminator Loss: 0.9510... Generator Loss: 1.4343
    Epoch 7/10... Discriminator Loss: 1.4054... Generator Loss: 1.8636
    Epoch 7/10... Discriminator Loss: 1.1205... Generator Loss: 0.7547
    Epoch 7/10... Discriminator Loss: 1.1586... Generator Loss: 0.8461
    Epoch 7/10... Discriminator Loss: 1.1787... Generator Loss: 0.6952
    Epoch 7/10... Discriminator Loss: 1.1886... Generator Loss: 0.4910



![png](output_25_105.png)


    Epoch 7/10... Discriminator Loss: 1.0664... Generator Loss: 0.9880
    Epoch 7/10... Discriminator Loss: 1.7180... Generator Loss: 0.3395
    Epoch 7/10... Discriminator Loss: 1.2605... Generator Loss: 1.0856
    Epoch 7/10... Discriminator Loss: 1.1707... Generator Loss: 0.8888
    Epoch 7/10... Discriminator Loss: 1.2361... Generator Loss: 0.6874
    Epoch 7/10... Discriminator Loss: 1.1012... Generator Loss: 0.8008
    Epoch 7/10... Discriminator Loss: 1.0995... Generator Loss: 0.9715
    Epoch 7/10... Discriminator Loss: 1.4171... Generator Loss: 0.4470
    Epoch 7/10... Discriminator Loss: 1.0465... Generator Loss: 0.5642
    Epoch 7/10... Discriminator Loss: 1.2159... Generator Loss: 0.8268



![png](output_25_107.png)


    Epoch 7/10... Discriminator Loss: 0.7588... Generator Loss: 0.9655
    Epoch 7/10... Discriminator Loss: 1.3894... Generator Loss: 0.9661
    Epoch 7/10... Discriminator Loss: 1.1726... Generator Loss: 0.8161
    Epoch 7/10... Discriminator Loss: 1.6431... Generator Loss: 0.3452
    Epoch 7/10... Discriminator Loss: 1.0905... Generator Loss: 1.2091
    Epoch 7/10... Discriminator Loss: 1.8158... Generator Loss: 0.2569
    Epoch 7/10... Discriminator Loss: 1.1115... Generator Loss: 1.0422
    Epoch 7/10... Discriminator Loss: 1.1689... Generator Loss: 1.2184
    Epoch 7/10... Discriminator Loss: 1.0192... Generator Loss: 1.3884
    Epoch 7/10... Discriminator Loss: 0.9732... Generator Loss: 1.2562



![png](output_25_109.png)


    Epoch 7/10... Discriminator Loss: 1.9524... Generator Loss: 1.3795
    Epoch 7/10... Discriminator Loss: 0.9524... Generator Loss: 0.7480
    Epoch 7/10... Discriminator Loss: 0.6134... Generator Loss: 1.8045
    Epoch 8/10... Discriminator Loss: 1.4162... Generator Loss: 2.3429
    Epoch 8/10... Discriminator Loss: 1.0619... Generator Loss: 1.9317
    Epoch 8/10... Discriminator Loss: 1.3631... Generator Loss: 1.7817
    Epoch 8/10... Discriminator Loss: 1.3843... Generator Loss: 1.1326
    Epoch 8/10... Discriminator Loss: 1.3406... Generator Loss: 0.4669
    Epoch 8/10... Discriminator Loss: 2.5188... Generator Loss: 3.6960
    Epoch 8/10... Discriminator Loss: 1.5391... Generator Loss: 0.3988



![png](output_25_111.png)


    Epoch 8/10... Discriminator Loss: 1.2532... Generator Loss: 0.8551
    Epoch 8/10... Discriminator Loss: 1.2070... Generator Loss: 0.5756
    Epoch 8/10... Discriminator Loss: 1.2119... Generator Loss: 0.5095
    Epoch 8/10... Discriminator Loss: 1.1573... Generator Loss: 0.8249
    Epoch 8/10... Discriminator Loss: 1.3956... Generator Loss: 0.5024
    Epoch 8/10... Discriminator Loss: 1.1522... Generator Loss: 0.7799
    Epoch 8/10... Discriminator Loss: 0.9730... Generator Loss: 0.8287
    Epoch 8/10... Discriminator Loss: 1.2377... Generator Loss: 0.5442
    Epoch 8/10... Discriminator Loss: 1.5326... Generator Loss: 0.3803
    Epoch 8/10... Discriminator Loss: 1.1203... Generator Loss: 0.8722



![png](output_25_113.png)


    Epoch 8/10... Discriminator Loss: 1.1637... Generator Loss: 0.8303
    Epoch 8/10... Discriminator Loss: 1.2281... Generator Loss: 1.3074
    Epoch 8/10... Discriminator Loss: 1.2523... Generator Loss: 0.8033
    Epoch 8/10... Discriminator Loss: 1.1886... Generator Loss: 0.7397
    Epoch 8/10... Discriminator Loss: 1.2289... Generator Loss: 0.7027
    Epoch 8/10... Discriminator Loss: 1.1961... Generator Loss: 0.5927
    Epoch 8/10... Discriminator Loss: 1.2544... Generator Loss: 1.3071
    Epoch 8/10... Discriminator Loss: 1.1980... Generator Loss: 1.4974
    Epoch 8/10... Discriminator Loss: 1.3908... Generator Loss: 0.5240
    Epoch 8/10... Discriminator Loss: 1.0738... Generator Loss: 0.8481



![png](output_25_115.png)


    Epoch 8/10... Discriminator Loss: 1.1653... Generator Loss: 0.6700
    Epoch 8/10... Discriminator Loss: 0.9907... Generator Loss: 1.1210
    Epoch 8/10... Discriminator Loss: 1.3108... Generator Loss: 0.5315
    Epoch 8/10... Discriminator Loss: 1.0077... Generator Loss: 1.2798
    Epoch 8/10... Discriminator Loss: 1.1282... Generator Loss: 2.1714
    Epoch 8/10... Discriminator Loss: 0.8358... Generator Loss: 1.2956
    Epoch 8/10... Discriminator Loss: 1.5487... Generator Loss: 0.3697
    Epoch 8/10... Discriminator Loss: 0.8139... Generator Loss: 1.0426
    Epoch 8/10... Discriminator Loss: 2.0556... Generator Loss: 2.8411
    Epoch 8/10... Discriminator Loss: 1.5884... Generator Loss: 1.4656



![png](output_25_117.png)


    Epoch 8/10... Discriminator Loss: 1.4494... Generator Loss: 1.8199
    Epoch 8/10... Discriminator Loss: 1.0581... Generator Loss: 0.7462
    Epoch 8/10... Discriminator Loss: 1.2728... Generator Loss: 1.5708
    Epoch 8/10... Discriminator Loss: 1.0970... Generator Loss: 0.7564
    Epoch 8/10... Discriminator Loss: 1.7822... Generator Loss: 0.3000
    Epoch 8/10... Discriminator Loss: 1.1262... Generator Loss: 0.8259
    Epoch 8/10... Discriminator Loss: 1.3285... Generator Loss: 0.6015
    Epoch 8/10... Discriminator Loss: 1.2159... Generator Loss: 0.6928
    Epoch 8/10... Discriminator Loss: 1.4231... Generator Loss: 0.4488
    Epoch 8/10... Discriminator Loss: 1.1311... Generator Loss: 0.9124



![png](output_25_119.png)


    Epoch 8/10... Discriminator Loss: 1.1291... Generator Loss: 1.0971
    Epoch 8/10... Discriminator Loss: 1.1316... Generator Loss: 0.7470
    Epoch 8/10... Discriminator Loss: 1.0947... Generator Loss: 0.5933
    Epoch 8/10... Discriminator Loss: 1.1515... Generator Loss: 0.6558
    Epoch 8/10... Discriminator Loss: 1.0109... Generator Loss: 0.6709
    Epoch 8/10... Discriminator Loss: 1.6913... Generator Loss: 0.2841
    Epoch 8/10... Discriminator Loss: 0.8194... Generator Loss: 1.3413
    Epoch 8/10... Discriminator Loss: 1.1925... Generator Loss: 0.8097
    Epoch 8/10... Discriminator Loss: 1.2271... Generator Loss: 0.7650
    Epoch 8/10... Discriminator Loss: 1.1901... Generator Loss: 1.4644



![png](output_25_121.png)


    Epoch 8/10... Discriminator Loss: 1.1557... Generator Loss: 0.9498
    Epoch 8/10... Discriminator Loss: 1.2337... Generator Loss: 1.0849
    Epoch 8/10... Discriminator Loss: 1.4660... Generator Loss: 0.4732
    Epoch 8/10... Discriminator Loss: 1.1353... Generator Loss: 0.7541
    Epoch 8/10... Discriminator Loss: 1.0028... Generator Loss: 0.6254
    Epoch 8/10... Discriminator Loss: 1.3817... Generator Loss: 1.1410
    Epoch 8/10... Discriminator Loss: 0.9919... Generator Loss: 0.8241
    Epoch 8/10... Discriminator Loss: 1.0533... Generator Loss: 1.5348
    Epoch 8/10... Discriminator Loss: 1.1693... Generator Loss: 0.5392
    Epoch 8/10... Discriminator Loss: 0.5912... Generator Loss: 1.5737



![png](output_25_123.png)


    Epoch 8/10... Discriminator Loss: 1.0433... Generator Loss: 0.9921
    Epoch 8/10... Discriminator Loss: 1.1000... Generator Loss: 1.1505
    Epoch 8/10... Discriminator Loss: 0.9078... Generator Loss: 0.6911
    Epoch 8/10... Discriminator Loss: 1.8034... Generator Loss: 0.2730
    Epoch 8/10... Discriminator Loss: 1.4615... Generator Loss: 0.4238
    Epoch 8/10... Discriminator Loss: 1.0374... Generator Loss: 1.0121
    Epoch 8/10... Discriminator Loss: 1.1261... Generator Loss: 0.7566
    Epoch 8/10... Discriminator Loss: 1.1719... Generator Loss: 1.1965
    Epoch 8/10... Discriminator Loss: 0.5714... Generator Loss: 1.3321
    Epoch 8/10... Discriminator Loss: 1.2717... Generator Loss: 0.6901



![png](output_25_125.png)


    Epoch 8/10... Discriminator Loss: 1.1406... Generator Loss: 1.1236
    Epoch 8/10... Discriminator Loss: 0.7265... Generator Loss: 0.9341
    Epoch 9/10... Discriminator Loss: 1.0788... Generator Loss: 2.3953
    Epoch 9/10... Discriminator Loss: 1.0115... Generator Loss: 0.6968
    Epoch 9/10... Discriminator Loss: 1.1573... Generator Loss: 1.0523
    Epoch 9/10... Discriminator Loss: 0.5144... Generator Loss: 1.5262
    Epoch 9/10... Discriminator Loss: 0.9418... Generator Loss: 1.1563
    Epoch 9/10... Discriminator Loss: 0.9891... Generator Loss: 0.9341
    Epoch 9/10... Discriminator Loss: 1.1293... Generator Loss: 0.9365
    Epoch 9/10... Discriminator Loss: 1.2370... Generator Loss: 0.6266



![png](output_25_127.png)


    Epoch 9/10... Discriminator Loss: 1.2631... Generator Loss: 0.6725
    Epoch 9/10... Discriminator Loss: 1.0978... Generator Loss: 0.7399
    Epoch 9/10... Discriminator Loss: 1.0482... Generator Loss: 0.9935
    Epoch 9/10... Discriminator Loss: 1.0843... Generator Loss: 1.1952
    Epoch 9/10... Discriminator Loss: 1.1638... Generator Loss: 0.8717
    Epoch 9/10... Discriminator Loss: 1.4706... Generator Loss: 0.7779
    Epoch 9/10... Discriminator Loss: 1.1473... Generator Loss: 0.6539
    Epoch 9/10... Discriminator Loss: 1.2615... Generator Loss: 0.6552
    Epoch 9/10... Discriminator Loss: 1.1736... Generator Loss: 1.2087
    Epoch 9/10... Discriminator Loss: 1.1810... Generator Loss: 0.6096



![png](output_25_129.png)


    Epoch 9/10... Discriminator Loss: 1.3020... Generator Loss: 0.5058
    Epoch 9/10... Discriminator Loss: 1.1965... Generator Loss: 0.6158
    Epoch 9/10... Discriminator Loss: 1.0813... Generator Loss: 1.0724
    Epoch 9/10... Discriminator Loss: 1.1652... Generator Loss: 0.6741
    Epoch 9/10... Discriminator Loss: 1.2896... Generator Loss: 1.4451
    Epoch 9/10... Discriminator Loss: 0.8860... Generator Loss: 1.6741
    Epoch 9/10... Discriminator Loss: 1.1196... Generator Loss: 0.9255
    Epoch 9/10... Discriminator Loss: 1.5332... Generator Loss: 0.4022
    Epoch 9/10... Discriminator Loss: 1.2014... Generator Loss: 0.9507
    Epoch 9/10... Discriminator Loss: 1.3600... Generator Loss: 0.4800



![png](output_25_131.png)


    Epoch 9/10... Discriminator Loss: 1.3903... Generator Loss: 1.4732
    Epoch 9/10... Discriminator Loss: 1.2243... Generator Loss: 1.0121
    Epoch 9/10... Discriminator Loss: 1.1485... Generator Loss: 0.7624
    Epoch 9/10... Discriminator Loss: 1.0204... Generator Loss: 0.8048
    Epoch 9/10... Discriminator Loss: 1.1030... Generator Loss: 0.6335
    Epoch 9/10... Discriminator Loss: 1.0722... Generator Loss: 0.8036
    Epoch 9/10... Discriminator Loss: 1.0933... Generator Loss: 1.7853
    Epoch 9/10... Discriminator Loss: 1.4139... Generator Loss: 0.4458
    Epoch 9/10... Discriminator Loss: 1.1330... Generator Loss: 0.8748
    Epoch 9/10... Discriminator Loss: 1.2631... Generator Loss: 0.6756



![png](output_25_133.png)


    Epoch 9/10... Discriminator Loss: 0.9889... Generator Loss: 1.0211
    Epoch 9/10... Discriminator Loss: 1.2804... Generator Loss: 0.5420
    Epoch 9/10... Discriminator Loss: 0.9927... Generator Loss: 0.8740
    Epoch 9/10... Discriminator Loss: 0.7978... Generator Loss: 1.1786
    Epoch 9/10... Discriminator Loss: 1.0145... Generator Loss: 0.7677
    Epoch 9/10... Discriminator Loss: 0.6691... Generator Loss: 1.1328
    Epoch 9/10... Discriminator Loss: 2.2543... Generator Loss: 0.5979
    Epoch 9/10... Discriminator Loss: 1.3543... Generator Loss: 0.5003
    Epoch 9/10... Discriminator Loss: 1.2064... Generator Loss: 0.7073
    Epoch 9/10... Discriminator Loss: 1.1511... Generator Loss: 0.7280



![png](output_25_135.png)


    Epoch 9/10... Discriminator Loss: 1.1271... Generator Loss: 0.9712
    Epoch 9/10... Discriminator Loss: 1.2700... Generator Loss: 0.7706
    Epoch 9/10... Discriminator Loss: 1.2157... Generator Loss: 0.9484
    Epoch 9/10... Discriminator Loss: 1.1648... Generator Loss: 1.0537
    Epoch 9/10... Discriminator Loss: 1.1841... Generator Loss: 1.0216
    Epoch 9/10... Discriminator Loss: 1.1225... Generator Loss: 0.7325
    Epoch 9/10... Discriminator Loss: 1.2395... Generator Loss: 0.6540
    Epoch 9/10... Discriminator Loss: 1.2478... Generator Loss: 0.6940
    Epoch 9/10... Discriminator Loss: 1.2785... Generator Loss: 0.6254
    Epoch 9/10... Discriminator Loss: 1.1485... Generator Loss: 0.7837



![png](output_25_137.png)


    Epoch 9/10... Discriminator Loss: 1.0290... Generator Loss: 0.6850
    Epoch 9/10... Discriminator Loss: 0.4977... Generator Loss: 1.2987
    Epoch 9/10... Discriminator Loss: 1.1961... Generator Loss: 0.9983
    Epoch 9/10... Discriminator Loss: 1.4734... Generator Loss: 1.6517
    Epoch 9/10... Discriminator Loss: 1.3402... Generator Loss: 0.6405
    Epoch 9/10... Discriminator Loss: 1.2054... Generator Loss: 1.0658
    Epoch 9/10... Discriminator Loss: 1.1838... Generator Loss: 0.6294
    Epoch 9/10... Discriminator Loss: 1.0715... Generator Loss: 1.3612
    Epoch 9/10... Discriminator Loss: 1.2923... Generator Loss: 0.5574
    Epoch 9/10... Discriminator Loss: 1.2192... Generator Loss: 0.6736



![png](output_25_139.png)


    Epoch 9/10... Discriminator Loss: 1.2079... Generator Loss: 0.6664
    Epoch 9/10... Discriminator Loss: 1.0941... Generator Loss: 0.8192
    Epoch 9/10... Discriminator Loss: 1.3095... Generator Loss: 0.7829
    Epoch 9/10... Discriminator Loss: 1.1153... Generator Loss: 0.6993
    Epoch 9/10... Discriminator Loss: 1.2807... Generator Loss: 0.5458
    Epoch 9/10... Discriminator Loss: 1.2784... Generator Loss: 0.5844
    Epoch 9/10... Discriminator Loss: 1.1101... Generator Loss: 0.9275
    Epoch 9/10... Discriminator Loss: 0.9885... Generator Loss: 0.6860
    Epoch 9/10... Discriminator Loss: 1.7011... Generator Loss: 1.8707
    Epoch 9/10... Discriminator Loss: 1.3716... Generator Loss: 0.4548



![png](output_25_141.png)


    Epoch 9/10... Discriminator Loss: 1.2363... Generator Loss: 0.6537
    Epoch 10/10... Discriminator Loss: 1.4299... Generator Loss: 1.1251
    Epoch 10/10... Discriminator Loss: 1.2087... Generator Loss: 1.2135
    Epoch 10/10... Discriminator Loss: 1.1565... Generator Loss: 0.7549
    Epoch 10/10... Discriminator Loss: 1.5999... Generator Loss: 0.3266
    Epoch 10/10... Discriminator Loss: 1.3733... Generator Loss: 0.4455
    Epoch 10/10... Discriminator Loss: 1.2599... Generator Loss: 0.4022
    Epoch 10/10... Discriminator Loss: 1.2362... Generator Loss: 0.6725
    Epoch 10/10... Discriminator Loss: 1.1713... Generator Loss: 0.7536
    Epoch 10/10... Discriminator Loss: 1.0575... Generator Loss: 0.8046



![png](output_25_143.png)


    Epoch 10/10... Discriminator Loss: 1.3152... Generator Loss: 1.4732
    Epoch 10/10... Discriminator Loss: 0.7659... Generator Loss: 1.5503
    Epoch 10/10... Discriminator Loss: 1.4768... Generator Loss: 0.4249
    Epoch 10/10... Discriminator Loss: 1.5254... Generator Loss: 0.5072
    Epoch 10/10... Discriminator Loss: 0.4808... Generator Loss: 2.0690
    Epoch 10/10... Discriminator Loss: 1.1349... Generator Loss: 1.0024
    Epoch 10/10... Discriminator Loss: 1.1129... Generator Loss: 1.2092
    Epoch 10/10... Discriminator Loss: 1.2528... Generator Loss: 0.6090
    Epoch 10/10... Discriminator Loss: 1.3441... Generator Loss: 0.4932
    Epoch 10/10... Discriminator Loss: 1.2953... Generator Loss: 0.5676



![png](output_25_145.png)


    Epoch 10/10... Discriminator Loss: 1.1156... Generator Loss: 0.6317
    Epoch 10/10... Discriminator Loss: 1.8174... Generator Loss: 1.4275
    Epoch 10/10... Discriminator Loss: 1.1990... Generator Loss: 1.5433
    Epoch 10/10... Discriminator Loss: 1.2114... Generator Loss: 0.6377
    Epoch 10/10... Discriminator Loss: 1.1132... Generator Loss: 1.2957
    Epoch 10/10... Discriminator Loss: 0.9919... Generator Loss: 1.0178
    Epoch 10/10... Discriminator Loss: 1.1184... Generator Loss: 0.8063
    Epoch 10/10... Discriminator Loss: 1.2101... Generator Loss: 0.6766
    Epoch 10/10... Discriminator Loss: 0.9489... Generator Loss: 0.9408
    Epoch 10/10... Discriminator Loss: 1.2396... Generator Loss: 0.9438



![png](output_25_147.png)


    Epoch 10/10... Discriminator Loss: 1.1649... Generator Loss: 0.8790
    Epoch 10/10... Discriminator Loss: 1.0677... Generator Loss: 1.1815
    Epoch 10/10... Discriminator Loss: 1.2778... Generator Loss: 0.5829
    Epoch 10/10... Discriminator Loss: 1.1126... Generator Loss: 0.7402
    Epoch 10/10... Discriminator Loss: 1.5711... Generator Loss: 0.3517
    Epoch 10/10... Discriminator Loss: 1.1701... Generator Loss: 0.8238
    Epoch 10/10... Discriminator Loss: 1.1805... Generator Loss: 0.6711
    Epoch 10/10... Discriminator Loss: 1.4544... Generator Loss: 1.9644
    Epoch 10/10... Discriminator Loss: 1.1345... Generator Loss: 0.7376
    Epoch 10/10... Discriminator Loss: 1.2546... Generator Loss: 0.8228



![png](output_25_149.png)


    Epoch 10/10... Discriminator Loss: 1.1076... Generator Loss: 0.7335
    Epoch 10/10... Discriminator Loss: 1.1291... Generator Loss: 0.8392
    Epoch 10/10... Discriminator Loss: 1.1352... Generator Loss: 0.8269
    Epoch 10/10... Discriminator Loss: 0.8526... Generator Loss: 1.0355
    Epoch 10/10... Discriminator Loss: 1.1031... Generator Loss: 0.8261
    Epoch 10/10... Discriminator Loss: 0.6021... Generator Loss: 1.0456
    Epoch 10/10... Discriminator Loss: 1.2222... Generator Loss: 0.9524
    Epoch 10/10... Discriminator Loss: 1.1452... Generator Loss: 0.7810
    Epoch 10/10... Discriminator Loss: 1.1390... Generator Loss: 1.2115
    Epoch 10/10... Discriminator Loss: 1.3412... Generator Loss: 0.4743



![png](output_25_151.png)


    Epoch 10/10... Discriminator Loss: 1.2246... Generator Loss: 0.6639
    Epoch 10/10... Discriminator Loss: 1.0595... Generator Loss: 0.7289
    Epoch 10/10... Discriminator Loss: 1.2990... Generator Loss: 0.5486
    Epoch 10/10... Discriminator Loss: 1.0807... Generator Loss: 0.7358
    Epoch 10/10... Discriminator Loss: 1.1625... Generator Loss: 0.7667
    Epoch 10/10... Discriminator Loss: 1.5095... Generator Loss: 0.3628
    Epoch 10/10... Discriminator Loss: 1.0519... Generator Loss: 0.8141
    Epoch 10/10... Discriminator Loss: 1.2053... Generator Loss: 0.9964
    Epoch 10/10... Discriminator Loss: 1.1714... Generator Loss: 0.5493
    Epoch 10/10... Discriminator Loss: 1.1393... Generator Loss: 1.7958



![png](output_25_153.png)


    Epoch 10/10... Discriminator Loss: 1.6717... Generator Loss: 2.5602
    Epoch 10/10... Discriminator Loss: 1.7161... Generator Loss: 0.8369
    Epoch 10/10... Discriminator Loss: 1.3119... Generator Loss: 0.6235
    Epoch 10/10... Discriminator Loss: 1.4382... Generator Loss: 0.4138
    Epoch 10/10... Discriminator Loss: 1.0652... Generator Loss: 1.0498
    Epoch 10/10... Discriminator Loss: 1.0797... Generator Loss: 0.9745
    Epoch 10/10... Discriminator Loss: 1.1763... Generator Loss: 0.7884
    Epoch 10/10... Discriminator Loss: 0.9578... Generator Loss: 1.2839
    Epoch 10/10... Discriminator Loss: 0.9191... Generator Loss: 1.2757
    Epoch 10/10... Discriminator Loss: 1.1729... Generator Loss: 1.2877



![png](output_25_155.png)


    Epoch 10/10... Discriminator Loss: 1.1664... Generator Loss: 0.7682
    Epoch 10/10... Discriminator Loss: 0.6974... Generator Loss: 1.2773
    Epoch 10/10... Discriminator Loss: 0.5703... Generator Loss: 1.1921
    Epoch 10/10... Discriminator Loss: 1.2217... Generator Loss: 0.5256
    Epoch 10/10... Discriminator Loss: 1.7612... Generator Loss: 0.3599
    Epoch 10/10... Discriminator Loss: 1.0039... Generator Loss: 0.9318
    Epoch 10/10... Discriminator Loss: 1.1036... Generator Loss: 0.8939
    Epoch 10/10... Discriminator Loss: 1.1061... Generator Loss: 1.0300
    Epoch 10/10... Discriminator Loss: 1.0479... Generator Loss: 0.9177
    Epoch 10/10... Discriminator Loss: 1.1828... Generator Loss: 0.6272



![png](output_25_157.png)


    Epoch 10/10... Discriminator Loss: 1.1890... Generator Loss: 0.7304


### Submitting This Project
When submitting this project, make sure to run all the cells before saving the notebook. Save the notebook file as "dlnd_face_generation.ipynb" and save it as a HTML file under "File" -> "Download as". Include the "helper.py" and "problem_unittests.py" files in your submission.
